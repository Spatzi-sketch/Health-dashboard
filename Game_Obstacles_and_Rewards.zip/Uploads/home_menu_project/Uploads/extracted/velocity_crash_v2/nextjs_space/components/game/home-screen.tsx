'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { GameSettings, GameStats, MapId, Difficulty, ArenaSpeed, BotStyle, PLAYER_COLORS } from '@/lib/game-types';
import { MAPS } from '@/lib/game-constants';
import { Trophy, Zap, Timer, Car, Palette, Map, Bot, Gauge } from 'lucide-react';

interface HomeScreenProps {
  onStart: (settings: GameSettings) => void;
}

const STATS_KEY = 'velocity_crash_stats';

function getDefaultSettings(): GameSettings {
  return {
    difficulty: 'medium',
    arenaSpeed: 'normal',
    map: 'tokyo-night',
    botStyle: 'tactical',
    playerColor: '#00e5ff',
  };
}

function loadStats(): GameStats {
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return { wins: 0, losses: 0, draws: 0, bestBrakeTime: null, closestDistance: null, gamesPlayed: 0 };
}

export default function HomeScreen({ onStart }: HomeScreenProps) {
  const [settings, setSettings] = useState<GameSettings>(getDefaultSettings);
  const [stats, setStats] = useState<GameStats>({ wins: 0, losses: 0, draws: 0, bestBrakeTime: null, closestDistance: null, gamesPlayed: 0 });

  useEffect(() => {
    setStats(loadStats());
  }, []);

  const selectedMap = MAPS.find((m) => m.id === settings.map) ?? MAPS[0];

  const updateSetting = <K extends keyof GameSettings>(key: K, value: GameSettings[K]) => {
    setSettings((prev) => ({ ...(prev ?? {}), [key]: value }));
  };

  return (
    <div className="min-h-screen w-full overflow-y-auto" style={{ background: 'linear-gradient(180deg, #020815 0%, #0a1530 50%, #050b18 100%)' }}>
      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Title */}
        <motion.div
          initial={{ y: -30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-center mb-8"
        >
          <h1
            className="text-5xl md:text-7xl font-bold tracking-tight font-display mb-2"
            style={{ color: '#00e5ff', textShadow: '0 0 40px rgba(0,229,255,0.4)' }}
          >
            VELOCITY CRASH
          </h1>
          <p className="text-white/50 text-sm">Brake late. Don&apos;t crash. Win.</p>
        </motion.div>

        {/* Map Selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <h2 className="text-white/70 text-sm font-bold uppercase mb-3 flex items-center gap-2">
            <Map size={16} /> SELECT MAP
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {MAPS.map((map, i) => (
              <motion.button
                key={map.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 + i * 0.05 }}
                onClick={() => updateSetting('map', map.id)}
                className="relative rounded-xl p-4 text-left transition-all border-2 overflow-hidden group"
                style={{
                  background: `linear-gradient(135deg, ${map.bgColor}, ${map.bgColor}ee)`,
                  borderColor: settings.map === map.id ? map.accentColor : 'rgba(255,255,255,0.1)',
                  boxShadow: settings.map === map.id ? `0 0 20px ${map.accentColor}44` : 'none',
                }}
              >
                <div className="text-2xl mb-1">{map.emoji}</div>
                <div className="text-sm font-bold text-white">{map.name}</div>
                <div className="text-xs text-white/40 mt-0.5">{map.description}</div>
                {/* Accent dot */}
                <div
                  className="absolute top-2 right-2 w-3 h-3 rounded-full"
                  style={{ background: map.accentColor, opacity: settings.map === map.id ? 1 : 0.3 }}
                />
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Settings Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8"
        >
          {/* Difficulty */}
          <SettingCard icon={<Zap size={16} />} title="DIFFICULTY">
            <div className="flex flex-wrap gap-2">
              {(['easy', 'medium', 'hard', 'impossible'] as Difficulty[]).map((d) => (
                <OptionBtn
                  key={d}
                  label={d.toUpperCase()}
                  active={settings.difficulty === d}
                  onClick={() => updateSetting('difficulty', d)}
                  color={selectedMap.accentColor}
                />
              ))}
            </div>
            {(settings.difficulty === 'hard' || settings.difficulty === 'impossible') && (
              <p className="text-xs text-yellow-400/70 mt-2">⚠️ Obstacles active on this difficulty</p>
            )}
          </SettingCard>

          {/* Arena Speed */}
          <SettingCard icon={<Gauge size={16} />} title="ARENA SPEED">
            <div className="flex flex-wrap gap-2">
              {(['slow', 'normal', 'fast', 'turbo'] as ArenaSpeed[]).map((s) => (
                <OptionBtn
                  key={s}
                  label={s.toUpperCase()}
                  active={settings.arenaSpeed === s}
                  onClick={() => updateSetting('arenaSpeed', s)}
                  color={selectedMap.accentColor}
                />
              ))}
            </div>
          </SettingCard>

          {/* Bot Style */}
          <SettingCard icon={<Bot size={16} />} title="BOT STYLE">
            <div className="flex flex-wrap gap-2">
              {(['aggressive', 'tactical', 'unpredictable'] as BotStyle[]).map((b) => (
                <OptionBtn
                  key={b}
                  label={b.toUpperCase()}
                  active={settings.botStyle === b}
                  onClick={() => updateSetting('botStyle', b)}
                  color={selectedMap.accentColor}
                />
              ))}
            </div>
          </SettingCard>

          {/* Player Color */}
          <SettingCard icon={<Palette size={16} />} title="PLAYER COLOR">
            <div className="flex flex-wrap gap-2">
              {PLAYER_COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => updateSetting('playerColor', c)}
                  className="w-9 h-9 rounded-lg border-2 transition-all hover:scale-110"
                  style={{
                    background: c,
                    borderColor: settings.playerColor === c ? '#fff' : 'rgba(255,255,255,0.15)',
                    boxShadow: settings.playerColor === c ? `0 0 12px ${c}88` : 'none',
                  }}
                />
              ))}
            </div>
          </SettingCard>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="rounded-xl p-4 mb-8 border border-white/10"
          style={{ background: 'rgba(255,255,255,0.03)' }}
        >
          <h3 className="text-white/50 text-xs font-bold uppercase mb-3 flex items-center gap-2">
            <Trophy size={14} /> YOUR STATS
          </h3>
          <div className="grid grid-cols-3 md:grid-cols-5 gap-3 text-center">
            <StatItem label="Wins" value={String(stats?.wins ?? 0)} color="#39ff14" />
            <StatItem label="Losses" value={String(stats?.losses ?? 0)} color="#ff3333" />
            <StatItem label="Draws" value={String(stats?.draws ?? 0)} color="#ffdd00" />
            <StatItem label="Best Brake" value={stats?.bestBrakeTime != null ? `${(stats.bestBrakeTime * 1000).toFixed(0)}ms` : '—'} color="#00e5ff" />
            <StatItem label="Games" value={String(stats?.gamesPlayed ?? 0)} color="#a78bfa" />
          </div>
        </motion.div>

        {/* Start Button */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center"
        >
          <button
            onClick={() => onStart?.(settings)}
            className="px-12 py-4 rounded-2xl text-xl font-bold text-black transition-all hover:scale-105 active:scale-95"
            style={{
              background: `linear-gradient(90deg, ${selectedMap.accentColor}, ${selectedMap.secondaryColor})`,
              boxShadow: `0 0 30px ${selectedMap.accentColor}44`,
            }}
          >
            START RACE
          </button>
          <p className="text-white/30 text-xs mt-3">Press SPACE to brake during the race</p>
        </motion.div>
      </div>
    </div>
  );
}

function SettingCard({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl p-4 border border-white/10" style={{ background: 'rgba(255,255,255,0.03)' }}>
      <h3 className="text-white/50 text-xs font-bold uppercase mb-3 flex items-center gap-2">
        {icon} {title}
      </h3>
      {children}
    </div>
  );
}

function OptionBtn({ label, active, onClick, color }: { label: string; active: boolean; onClick: () => void; color: string }) {
  return (
    <button
      onClick={onClick}
      className="px-3 py-1.5 rounded-lg text-xs font-bold transition-all"
      style={{
        background: active ? color + '22' : 'rgba(255,255,255,0.05)',
        color: active ? color : 'rgba(255,255,255,0.5)',
        border: `1px solid ${active ? color + '55' : 'rgba(255,255,255,0.1)'}`,
      }}
    >
      {label}
    </button>
  );
}

function StatItem({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div>
      <div className="text-lg font-bold font-mono" style={{ color }}>{value}</div>
      <div className="text-xs text-white/40">{label}</div>
    </div>
  );
}
