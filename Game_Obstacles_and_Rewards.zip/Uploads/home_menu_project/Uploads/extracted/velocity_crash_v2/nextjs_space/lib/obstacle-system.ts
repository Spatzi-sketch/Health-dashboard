import { Obstacle, ObstacleEffect, Difficulty } from './game-types';
import { ARENA_WIDTH } from './game-constants';

export function shouldHaveObstacles(difficulty: Difficulty): boolean {
  return difficulty === 'hard' || difficulty === 'impossible';
}

export function generateObstacles(difficulty: Difficulty, canvasH: number): Obstacle[] {
  if (!shouldHaveObstacles(difficulty)) return [];
  const count = difficulty === 'impossible' ? 2 + Math.floor(Math.random() * 2) : 1 + Math.floor(Math.random() * 2);
  const obstacles: Obstacle[] = [];
  const types: Array<'barrier' | 'oil-slick' | 'speed-burst'> = ['barrier', 'oil-slick', 'speed-burst'];

  for (let i = 0; i < count; i++) {
    const type = types[i % types.length];
    obstacles.push({
      type,
      x: 200 + Math.random() * (ARENA_WIDTH - 400),
      width: type === 'oil-slick' ? 60 : type === 'speed-burst' ? 50 : 30,
      active: true,
      timer: 0,
      y: canvasH * 0.5 - 30 + (type === 'barrier' ? 0 : Math.random() * 20),
      direction: 1,
    });
  }
  return obstacles;
}

export function updateObstacles(obstacles: Obstacle[], dt: number, canvasH: number): Obstacle[] {
  return obstacles.map((o) => {
    if (o.type === 'barrier') {
      const newY = o.y + o.direction * 40 * dt;
      let dir = o.direction;
      if (newY > canvasH * 0.5 + 40) dir = -1;
      if (newY < canvasH * 0.5 - 80) dir = 1;
      return { ...o, y: newY, direction: dir, timer: o.timer + dt };
    }
    return { ...o, timer: o.timer + dt };
  });
}

export function checkObstacleCollision(
  carX: number,
  obstacles: Obstacle[],
  existingEffects: ObstacleEffect[]
): { effects: ObstacleEffect[]; obstacles: Obstacle[] } {
  const newEffects = [...existingEffects];
  const updatedObstacles = obstacles.map((o) => {
    if (!o.active) return o;
    if (carX >= o.x - o.width / 2 && carX <= o.x + o.width / 2) {
      switch (o.type) {
        case 'barrier':
          newEffects.push({ type: 'barrier', timeLeft: 1.0 });
          break;
        case 'oil-slick':
          newEffects.push({ type: 'oil-slick', timeLeft: 1.5 });
          break;
        case 'speed-burst':
          newEffects.push({ type: 'speed-burst', timeLeft: 0.8 });
          break;
      }
      return { ...o, active: false };
    }
    return o;
  });
  return { effects: newEffects, obstacles: updatedObstacles };
}

export function updateEffects(effects: ObstacleEffect[], dt: number): ObstacleEffect[] {
  return effects
    .map((e) => ({ ...e, timeLeft: e.timeLeft - dt }))
    .filter((e) => e.timeLeft > 0);
}

export function getBrakeMultiplier(effects: ObstacleEffect[]): number {
  let mult = 1.0;
  for (const e of effects ?? []) {
    if (e.type === 'barrier') mult *= 0.7;
    if (e.type === 'oil-slick') mult *= 0.6;
  }
  return mult;
}

export function getAccelMultiplier(effects: ObstacleEffect[]): number {
  let mult = 1.0;
  for (const e of effects ?? []) {
    if (e.type === 'speed-burst') mult *= 1.5;
  }
  return mult;
}

export function drawObstacle(ctx: CanvasRenderingContext2D, o: Obstacle, scaleX: number, roadY: number, roadH: number): void {
  if (!o.active) return;
  const sx = o.x * scaleX;
  const sw = o.width * scaleX;

  ctx.save();
  switch (o.type) {
    case 'barrier': {
      ctx.fillStyle = '#ff4400';
      ctx.shadowBlur = 8;
      ctx.shadowColor = '#ff4400';
      ctx.fillRect(sx - sw / 2, roadY - 5, sw, roadH + 10);
      ctx.strokeStyle = '#ffaa00';
      ctx.lineWidth = 2;
      ctx.strokeRect(sx - sw / 2, roadY - 5, sw, roadH + 10);
      // Warning stripes
      ctx.fillStyle = '#ffaa00';
      for (let i = 0; i < 3; i++) {
        ctx.fillRect(sx - sw / 2 + i * (sw / 3), roadY - 5, sw / 6, roadH + 10);
      }
      ctx.shadowBlur = 0;
      break;
    }
    case 'oil-slick': {
      const gradient = ctx.createRadialGradient(sx, roadY + roadH / 2, 0, sx, roadY + roadH / 2, sw);
      gradient.addColorStop(0, 'rgba(100,50,200,0.6)');
      gradient.addColorStop(0.5, 'rgba(50,150,200,0.4)');
      gradient.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.ellipse(sx, roadY + roadH / 2, sw, roadH * 0.6, 0, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case 'speed-burst': {
      ctx.fillStyle = '#ffdd00';
      ctx.shadowBlur = 12;
      ctx.shadowColor = '#ffdd00';
      ctx.beginPath();
      const cy = roadY + roadH / 2;
      // Lightning bolt shape
      ctx.moveTo(sx - sw * 0.3, cy - 15);
      ctx.lineTo(sx + sw * 0.1, cy - 3);
      ctx.lineTo(sx - sw * 0.1, cy + 3);
      ctx.lineTo(sx + sw * 0.3, cy + 15);
      ctx.lineTo(sx, cy + 3);
      ctx.lineTo(sx + sw * 0.15, cy - 3);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;
      break;
    }
  }
  ctx.restore();
}
