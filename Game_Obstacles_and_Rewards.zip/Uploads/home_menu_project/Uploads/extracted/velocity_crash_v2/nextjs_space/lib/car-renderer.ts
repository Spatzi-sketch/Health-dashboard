export function drawCar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  color: string,
  facing: 'right' | 'left',
  speed: number,
  maxSpeed: number
): void {
  ctx.save();
  ctx.translate(x, y);
  if (facing === 'left') {
    ctx.scale(-1, 1);
    ctx.translate(-w, 0);
  }

  // Glow based on speed
  const speedRatio = Math.min(1, speed / Math.max(1, maxSpeed));
  if (speedRatio > 0.3) {
    ctx.shadowBlur = 15 * speedRatio;
    ctx.shadowColor = color;
  }

  // Car body (cel-shaded style)
  const bodyH = h * 0.6;
  const bodyY = h * 0.2;

  // Main body
  ctx.fillStyle = color;
  ctx.strokeStyle = '#000';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.roundRect(2, bodyY, w - 4, bodyH, 4);
  ctx.fill();
  ctx.stroke();

  // Roof / cabin
  ctx.fillStyle = darkenColor(color, 0.3);
  ctx.beginPath();
  ctx.moveTo(w * 0.35, bodyY);
  ctx.lineTo(w * 0.45, bodyY - h * 0.18);
  ctx.lineTo(w * 0.75, bodyY - h * 0.18);
  ctx.lineTo(w * 0.85, bodyY);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Windshield
  ctx.fillStyle = 'rgba(100,200,255,0.4)';
  ctx.beginPath();
  ctx.moveTo(w * 0.38, bodyY + 1);
  ctx.lineTo(w * 0.47, bodyY - h * 0.14);
  ctx.lineTo(w * 0.65, bodyY - h * 0.14);
  ctx.lineTo(w * 0.68, bodyY + 1);
  ctx.closePath();
  ctx.fill();

  // Front highlight (cel shade)
  ctx.fillStyle = lightenColor(color, 0.3);
  ctx.fillRect(w * 0.8, bodyY + 3, w * 0.15, bodyH * 0.4);

  // Headlight
  ctx.fillStyle = '#ffee88';
  ctx.shadowBlur = 8;
  ctx.shadowColor = '#ffee88';
  ctx.beginPath();
  ctx.ellipse(w - 3, bodyY + bodyH * 0.3, 3, 5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // Tail light
  ctx.fillStyle = '#ff3333';
  ctx.beginPath();
  ctx.ellipse(3, bodyY + bodyH * 0.3, 2, 4, 0, 0, Math.PI * 2);
  ctx.fill();

  // Wheels
  ctx.fillStyle = '#111';
  ctx.strokeStyle = '#333';
  ctx.lineWidth = 1.5;
  const wheelR = h * 0.14;
  // Front wheel
  ctx.beginPath();
  ctx.arc(w * 0.78, bodyY + bodyH, wheelR, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // Rear wheel
  ctx.beginPath();
  ctx.arc(w * 0.22, bodyY + bodyH, wheelR, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Wheel hubcaps
  ctx.fillStyle = '#555';
  ctx.beginPath();
  ctx.arc(w * 0.78, bodyY + bodyH, wheelR * 0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(w * 0.22, bodyY + bodyH, wheelR * 0.4, 0, Math.PI * 2);
  ctx.fill();

  ctx.shadowBlur = 0;
  ctx.restore();
}

function darkenColor(hex: string, amount: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgb(${Math.round(r * (1 - amount))},${Math.round(g * (1 - amount))},${Math.round(b * (1 - amount))})`;
}

function lightenColor(hex: string, amount: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgb(${Math.min(255, Math.round(r + (255 - r) * amount))},${Math.min(255, Math.round(g + (255 - g) * amount))},${Math.min(255, Math.round(b + (255 - b) * amount))})`;
}

export function drawSpeedLines(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  speed: number,
  maxSpeed: number,
  accentColor: string
): void {
  const ratio = speed / Math.max(1, maxSpeed);
  if (ratio < 0.4) return;

  const intensity = (ratio - 0.4) / 0.6;
  const lineCount = Math.floor(intensity * 20);
  const cx = w / 2;
  const cy = h / 2;

  ctx.save();
  ctx.globalAlpha = intensity * 0.3;
  ctx.strokeStyle = accentColor;
  ctx.lineWidth = 1 + intensity;

  for (let i = 0; i < lineCount; i++) {
    const angle = (Math.PI * 2 * i) / lineCount + Math.random() * 0.3;
    const innerR = 80 + Math.random() * 60;
    const outerR = innerR + 100 + intensity * 200;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(angle) * innerR, cy + Math.sin(angle) * innerR);
    ctx.lineTo(cx + Math.cos(angle) * outerR, cy + Math.sin(angle) * outerR);
    ctx.stroke();
  }
  ctx.restore();
}
