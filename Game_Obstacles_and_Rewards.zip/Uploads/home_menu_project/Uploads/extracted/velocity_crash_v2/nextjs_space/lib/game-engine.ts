import {
  GameState, GameSettings, Obstacle, ObstacleEffect, Difficulty, BotStyle,
} from './game-types';
import {
  ARENA_WIDTH, CAR_WIDTH, BASE_ACCELERATION, BASE_MAX_VELOCITY,
  BRAKE_DECELERATION, SAFE_SPEED, SPEED_MULTIPLIERS, BOT_DELAY,
} from './game-constants';
import {
  getBrakeMultiplier, getAccelMultiplier, checkObstacleCollision,
  updateObstacles, updateEffects, generateObstacles, shouldHaveObstacles,
} from './obstacle-system';

export function createInitialState(settings: GameSettings, canvasH: number): GameState {
  return {
    phase: 'countdown',
    countdownValue: 3,
    playerPos: 0,
    playerVel: 0,
    playerBraking: false,
    botPos: ARENA_WIDTH,
    botVel: 0,
    botBraking: false,
    winner: null,
    resultType: null,
    playerBrakeTime: 0,
    botBrakeTime: 0,
    raceStartTime: 0,
    elapsed: 0,
    playerEffects: [],
    botEffects: [],
    obstacles: shouldHaveObstacles(settings.difficulty)
      ? generateObstacles(settings.difficulty, canvasH)
      : [],
    impactText: null,
    impactTextTimer: 0,
    shakeIntensity: 0,
  };
}

export function updateGameState(
  state: GameState,
  dt: number,
  settings: GameSettings,
  playerBrakeInput: boolean,
  canvasH: number
): GameState {
  if (state.phase !== 'racing') return state;

  const speedMult = SPEED_MULTIPLIERS[settings.arenaSpeed] ?? 1;
  const accel = BASE_ACCELERATION * speedMult;
  const maxVel = BASE_MAX_VELOCITY * speedMult;
  const brakePower = BRAKE_DECELERATION * speedMult;
  const elapsed = state.elapsed + dt;

  let playerVel = state.playerVel;
  let playerPos = state.playerPos;
  let playerBraking = state.playerBraking;
  let playerBrakeTime = state.playerBrakeTime;
  let playerEffects = updateEffects([...(state.playerEffects ?? [])], dt);

  let botVel = state.botVel;
  let botPos = state.botPos;
  let botBraking = state.botBraking;
  let botBrakeTime = state.botBrakeTime;
  let botEffects = updateEffects([...(state.botEffects ?? [])], dt);

  let obstacles = updateObstacles([...(state.obstacles ?? [])], dt, canvasH);
  let impactText = state.impactText;
  let impactTextTimer = Math.max(0, (state.impactTextTimer ?? 0) - dt);
  let shakeIntensity = Math.max(0, (state.shakeIntensity ?? 0) - dt * 10);

  if (impactTextTimer <= 0) impactText = null;

  // Player brake input
  if (playerBrakeInput && !playerBraking) {
    playerBraking = true;
    playerBrakeTime = elapsed;
    impactText = 'BRAKE!';
    impactTextTimer = 0.8;
  }

  // Player physics
  const pAccelMult = getAccelMultiplier(playerEffects);
  const pBrakeMult = getBrakeMultiplier(playerEffects);
  if (playerBraking) {
    playerVel = Math.max(0, playerVel - brakePower * pBrakeMult * dt);
  } else {
    playerVel = Math.min(maxVel, playerVel + accel * pAccelMult * dt);
  }
  playerPos = playerPos + playerVel * dt;

  // Bot AI
  const botAccelMult = getAccelMultiplier(botEffects);
  const botBrakeMult = getBrakeMultiplier(botEffects);
  if (!botBraking) {
    botVel = Math.min(maxVel, botVel + accel * botAccelMult * dt);
    botPos = botPos - botVel * dt;

    // Bot brake decision
    const gap = botPos - playerPos;
    const closingSpeed = playerVel + botVel;
    const stoppingDist = (botVel * botVel) / (2 * brakePower * botBrakeMult);
    const playerStoppingDist = (playerVel * playerVel) / (2 * brakePower);
    const totalStoppingDist = stoppingDist + playerStoppingDist;
    
    const delayMs = BOT_DELAY[settings.difficulty] ?? 400;
    const riskFactor = getRiskFactor(settings.botStyle, settings.difficulty);
    const brakeThreshold = totalStoppingDist + CAR_WIDTH + (delayMs / 1000) * closingSpeed;

    if (gap <= brakeThreshold * riskFactor) {
      botBraking = true;
      botBrakeTime = elapsed;
    }
  } else {
    botVel = Math.max(0, botVel - brakePower * botBrakeMult * dt);
    botPos = botPos - botVel * dt;
  }

  // Obstacle collisions
  if ((obstacles?.length ?? 0) > 0) {
    const pResult = checkObstacleCollision(playerPos, obstacles, playerEffects);
    playerEffects = pResult.effects;
    obstacles = pResult.obstacles;

    const bResult = checkObstacleCollision(ARENA_WIDTH - botPos, obstacles, botEffects);
    botEffects = bResult.effects;
    obstacles = bResult.obstacles;
  }

  // Collision detection
  const gap = botPos - playerPos;
  let winner = state.winner;
  let resultType = state.resultType;
  let phase: GameState['phase'] = 'racing';

  if (gap <= CAR_WIDTH) {
    // Cars have met/overlapped
    if (playerVel > SAFE_SPEED || botVel > SAFE_SPEED) {
      // CRASH!
      resultType = 'crash';
      impactText = 'CRASH!';
      impactTextTimer = 2;
      shakeIntensity = 15;
      if (playerVel <= SAFE_SPEED) {
        winner = 'player';
      } else if (botVel <= SAFE_SPEED) {
        winner = 'bot';
      } else {
        winner = playerVel <= botVel ? 'player' : 'bot';
      }
      phase = 'result';
    } else {
      // Both safe
      resultType = 'safe';
      phase = 'result';
      // Winner = whoever got closer (braked later / more daring)
      if (Math.abs(playerBrakeTime - botBrakeTime) < 0.05) {
        winner = 'draw';
      } else {
        winner = playerBrakeTime > botBrakeTime ? 'player' : 'bot';
      }
      impactText = winner === 'player' ? 'VICTORY!' : winner === 'bot' ? 'DEFEAT!' : 'DRAW!';
      impactTextTimer = 2;
    }
  } else if (playerVel <= 0.1 && botVel <= 0.1 && playerBraking && botBraking) {
    // Both stopped but didn't reach each other
    resultType = 'safe';
    phase = 'result';
    // Winner = whoever got physically closer
    const playerDist = playerPos;
    const botDist = ARENA_WIDTH - botPos;
    if (Math.abs(playerDist - botDist) < 5) {
      winner = 'draw';
    } else {
      winner = playerDist > botDist ? 'player' : 'bot';
    }
    impactText = winner === 'player' ? 'VICTORY!' : winner === 'bot' ? 'DEFEAT!' : 'DRAW!';
    impactTextTimer = 2;
  }

  return {
    ...state,
    phase,
    playerPos,
    playerVel,
    playerBraking,
    playerBrakeTime,
    botPos,
    botVel,
    botBraking,
    botBrakeTime,
    elapsed,
    winner,
    resultType,
    playerEffects,
    botEffects,
    obstacles,
    impactText,
    impactTextTimer,
    shakeIntensity,
  };
}

function getRiskFactor(botStyle: BotStyle, difficulty: Difficulty): number {
  const base: Record<BotStyle, number> = {
    aggressive: 0.85,
    tactical: 1.1,
    unpredictable: 0.7 + Math.random() * 0.6,
  };
  const diffMod: Record<Difficulty, number> = {
    easy: 1.3,
    medium: 1.1,
    hard: 0.95,
    impossible: 0.82,
  };
  return (base[botStyle] ?? 1) * (diffMod[difficulty] ?? 1);
}
