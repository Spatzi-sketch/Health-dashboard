import { MapId } from './game-types';

export function drawMapBackground(
  ctx: CanvasRenderingContext2D,
  mapId: MapId,
  w: number,
  h: number,
  time: number
): void {
  switch (mapId) {
    case 'tokyo-night':
      drawTokyoNight(ctx, w, h, time);
      break;
    case 'sakura-pass':
      drawSakuraPass(ctx, w, h, time);
      break;
    case 'neon-circuit':
      drawNeonCircuit(ctx, w, h, time);
      break;
    case 'ocean-drive':
      drawOceanDrive(ctx, w, h, time);
      break;
    case 'space-drift':
      drawSpaceDrift(ctx, w, h, time);
      break;
    case 'crimson-dojo':
      drawCrimsonDojo(ctx, w, h, time);
      break;
  }
}

function drawTokyoNight(ctx: CanvasRenderingContext2D, w: number, h: number, t: number): void {
  // Dark sky
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, '#020815');
  grad.addColorStop(0.4, '#050b18');
  grad.addColorStop(1, '#0a1530');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // City skyline
  ctx.fillStyle = '#0a0f20';
  const buildings = [40, 80, 55, 100, 65, 90, 45, 110, 70, 50, 85, 60, 95, 75, 40, 88, 55, 105, 68, 48];
  const bw = w / buildings.length;
  buildings.forEach((bh, i) => {
    const yy = h * 0.35 - bh;
    ctx.fillRect(i * bw, yy, bw - 2, bh + 20);
    // Windows
    ctx.fillStyle = Math.random() > 0.6 ? '#00e5ff22' : '#ff00ff11';
    for (let wy = yy + 5; wy < yy + bh; wy += 12) {
      for (let wx = i * bw + 3; wx < (i + 1) * bw - 5; wx += 8) {
        if (Math.random() > 0.4) {
          ctx.fillRect(wx, wy, 4, 6);
        }
      }
    }
    ctx.fillStyle = '#0a0f20';
  });

  // Neon glow reflections on road area
  ctx.fillStyle = 'rgba(0,229,255,0.03)';
  ctx.fillRect(0, h * 0.45, w, h * 0.15);
  ctx.fillStyle = 'rgba(255,0,255,0.02)';
  ctx.fillRect(0, h * 0.5, w, h * 0.1);
}

function drawSakuraPass(ctx: CanvasRenderingContext2D, w: number, h: number, t: number): void {
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, '#ff9ec7');
  grad.addColorStop(0.3, '#c084fc');
  grad.addColorStop(0.6, '#1a0a1e');
  grad.addColorStop(1, '#0d0510');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Mount Fuji silhouette
  ctx.fillStyle = '#2a1040';
  ctx.beginPath();
  ctx.moveTo(w * 0.3, h * 0.45);
  ctx.lineTo(w * 0.5, h * 0.15);
  ctx.lineTo(w * 0.7, h * 0.45);
  ctx.closePath();
  ctx.fill();
  // Snow cap
  ctx.fillStyle = '#e8d0f0';
  ctx.beginPath();
  ctx.moveTo(w * 0.44, h * 0.22);
  ctx.lineTo(w * 0.5, h * 0.15);
  ctx.lineTo(w * 0.56, h * 0.22);
  ctx.quadraticCurveTo(w * 0.52, h * 0.25, w * 0.5, h * 0.23);
  ctx.quadraticCurveTo(w * 0.48, h * 0.25, w * 0.44, h * 0.22);
  ctx.fill();
}

function drawNeonCircuit(ctx: CanvasRenderingContext2D, w: number, h: number, t: number): void {
  ctx.fillStyle = '#000510';
  ctx.fillRect(0, 0, w, h);

  // Grid lines
  ctx.strokeStyle = 'rgba(57,255,20,0.08)';
  ctx.lineWidth = 1;
  const gridSize = 40;
  for (let x = 0; x < w; x += gridSize) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 0; y < h; y += gridSize) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }

  // Pulsing nodes
  const pulse = Math.sin(t * 3) * 0.5 + 0.5;
  ctx.fillStyle = `rgba(57,255,20,${0.1 + pulse * 0.15})`;
  for (let x = gridSize; x < w; x += gridSize * 3) {
    for (let y = gridSize; y < h; y += gridSize * 3) {
      ctx.beginPath();
      ctx.arc(x, y, 3 + pulse * 2, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

function drawOceanDrive(ctx: CanvasRenderingContext2D, w: number, h: number, t: number): void {
  // Sunset sky
  const grad = ctx.createLinearGradient(0, 0, 0, h * 0.5);
  grad.addColorStop(0, '#1a0533');
  grad.addColorStop(0.4, '#ff6b35');
  grad.addColorStop(0.7, '#ff9e5e');
  grad.addColorStop(1, '#0a1628');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Sun
  ctx.fillStyle = '#ffcc00';
  ctx.shadowBlur = 30;
  ctx.shadowColor = '#ff6b35';
  ctx.beginPath();
  ctx.arc(w * 0.7, h * 0.25, 30, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // Ocean waves
  ctx.fillStyle = '#0a3060';
  ctx.beginPath();
  ctx.moveTo(0, h * 0.4);
  for (let x = 0; x <= w; x += 20) {
    const waveY = h * 0.4 + Math.sin(x * 0.02 + t * 2) * 8 + Math.sin(x * 0.05 + t * 3) * 4;
    ctx.lineTo(x, waveY);
  }
  ctx.lineTo(w, h * 0.5);
  ctx.lineTo(0, h * 0.5);
  ctx.closePath();
  ctx.fill();
}

function drawSpaceDrift(ctx: CanvasRenderingContext2D, w: number, h: number, t: number): void {
  ctx.fillStyle = '#020010';
  ctx.fillRect(0, 0, w, h);

  // Nebula gradients
  const g1 = ctx.createRadialGradient(w * 0.3, h * 0.3, 0, w * 0.3, h * 0.3, w * 0.4);
  g1.addColorStop(0, 'rgba(167,139,250,0.08)');
  g1.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g1;
  ctx.fillRect(0, 0, w, h);

  const g2 = ctx.createRadialGradient(w * 0.7, h * 0.6, 0, w * 0.7, h * 0.6, w * 0.3);
  g2.addColorStop(0, 'rgba(236,72,153,0.06)');
  g2.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g2;
  ctx.fillRect(0, 0, w, h);

  // Static stars (seeded by position)
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 80; i++) {
    const sx = ((i * 137.5) % w);
    const sy = ((i * 89.3) % h);
    const ss = 0.5 + (i % 3) * 0.5;
    const twinkle = Math.sin(t * 2 + i) * 0.3 + 0.7;
    ctx.globalAlpha = twinkle;
    ctx.beginPath();
    ctx.arc(sx, sy, ss, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}

function drawCrimsonDojo(ctx: CanvasRenderingContext2D, w: number, h: number, t: number): void {
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, '#0d0000');
  grad.addColorStop(0.5, '#1a0500');
  grad.addColorStop(1, '#0d0000');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Torii gate silhouette
  ctx.fillStyle = '#1a0000';
  const gx = w * 0.5;
  const gy = h * 0.15;
  // Pillars
  ctx.fillRect(gx - 80, gy, 12, h * 0.35);
  ctx.fillRect(gx + 68, gy, 12, h * 0.35);
  // Top beam
  ctx.fillRect(gx - 95, gy - 8, 190, 12);
  // Second beam
  ctx.fillRect(gx - 85, gy + 25, 170, 8);
  // Curved top
  ctx.beginPath();
  ctx.moveTo(gx - 100, gy - 8);
  ctx.quadraticCurveTo(gx, gy - 30, gx + 100, gy - 8);
  ctx.lineTo(gx + 95, gy - 4);
  ctx.quadraticCurveTo(gx, gy - 24, gx - 95, gy - 4);
  ctx.closePath();
  ctx.fill();

  // Smoke wisps
  ctx.globalAlpha = 0.06;
  ctx.fillStyle = '#ff3300';
  for (let i = 0; i < 5; i++) {
    const sx = w * (0.1 + i * 0.2);
    const sy = h * 0.5 + Math.sin(t + i * 2) * 20;
    ctx.beginPath();
    ctx.ellipse(sx, sy, 40 + Math.sin(t * 0.5 + i) * 10, 15, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}
