import { Particle, MapId } from './game-types';

export function createParticle(mapId: MapId, canvasW: number, canvasH: number): Particle {
  switch (mapId) {
    case 'tokyo-night':
      return {
        x: Math.random() * canvasW,
        y: -10,
        vx: -1.5 - Math.random() * 2,
        vy: 8 + Math.random() * 6,
        size: 1 + Math.random() * 1.5,
        opacity: 0.3 + Math.random() * 0.4,
        color: Math.random() > 0.5 ? '#00e5ff' : '#ccddff',
        rotation: 0,
        rotationSpeed: 0,
        life: 0,
        maxLife: 200,
      };
    case 'sakura-pass':
      return {
        x: Math.random() * canvasW,
        y: -10,
        vx: -0.5 + Math.random() * 1,
        vy: 1 + Math.random() * 2,
        size: 3 + Math.random() * 5,
        opacity: 0.5 + Math.random() * 0.5,
        color: Math.random() > 0.3 ? '#ffb7d5' : '#ffffff',
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.05,
        life: 0,
        maxLife: 400,
      };
    case 'neon-circuit':
      return {
        x: Math.random() * canvasW,
        y: Math.random() * canvasH,
        vx: (Math.random() - 0.5) * 4,
        vy: (Math.random() - 0.5) * 4,
        size: 1 + Math.random() * 2,
        opacity: 0.8,
        color: Math.random() > 0.5 ? '#39ff14' : '#ff00ff',
        rotation: 0,
        rotationSpeed: 0,
        life: 0,
        maxLife: 60,
      };
    case 'ocean-drive':
      return {
        x: Math.random() * canvasW,
        y: canvasH * 0.3 + Math.random() * canvasH * 0.2,
        vx: 0.5 + Math.random() * 1,
        vy: -1 - Math.random() * 2,
        size: 2 + Math.random() * 3,
        opacity: 0.4 + Math.random() * 0.3,
        color: '#ffffff',
        rotation: 0,
        rotationSpeed: 0,
        life: 0,
        maxLife: 80,
      };
    case 'space-drift':
      return {
        x: Math.random() * canvasW,
        y: Math.random() * canvasH,
        vx: -2 - Math.random() * 3,
        vy: 0.5 + Math.random() * 1,
        size: 1 + Math.random() * 2,
        opacity: 0.6 + Math.random() * 0.4,
        color: Math.random() > 0.6 ? '#a78bfa' : Math.random() > 0.3 ? '#ec4899' : '#ffffff',
        rotation: 0,
        rotationSpeed: 0,
        life: 0,
        maxLife: 150,
      };
    case 'crimson-dojo':
      return {
        x: Math.random() * canvasW,
        y: canvasH + 5,
        vx: (Math.random() - 0.5) * 2,
        vy: -2 - Math.random() * 4,
        size: 1.5 + Math.random() * 3,
        opacity: 0.7 + Math.random() * 0.3,
        color: Math.random() > 0.5 ? '#ff3300' : '#ff8c00',
        rotation: 0,
        rotationSpeed: 0,
        life: 0,
        maxLife: 120,
      };
    default:
      return {
        x: 0, y: 0, vx: 0, vy: 0, size: 1, opacity: 1,
        color: '#fff', rotation: 0, rotationSpeed: 0, life: 0, maxLife: 100,
      };
  }
}

export function updateParticles(particles: Particle[], dt: number): Particle[] {
  return particles
    .map((p) => ({
      ...p,
      x: p.x + p.vx,
      y: p.y + p.vy,
      rotation: p.rotation + p.rotationSpeed,
      life: p.life + 1,
      opacity: Math.max(0, p.opacity * (1 - p.life / p.maxLife)),
    }))
    .filter((p) => p.life < p.maxLife && p.opacity > 0.01);
}

export function drawParticle(ctx: CanvasRenderingContext2D, p: Particle, mapId: MapId): void {
  ctx.save();
  ctx.globalAlpha = p.opacity;
  ctx.fillStyle = p.color;

  if (mapId === 'sakura-pass') {
    ctx.translate(p.x, p.y);
    ctx.rotate(p.rotation);
    // Draw petal shape
    ctx.beginPath();
    ctx.ellipse(0, 0, p.size, p.size * 0.6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(0, 0, p.size * 0.6, p.size, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (mapId === 'tokyo-night') {
    // Rain streak
    ctx.strokeStyle = p.color;
    ctx.lineWidth = p.size * 0.5;
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.lineTo(p.x + p.vx * 3, p.y + p.vy * 3);
    ctx.stroke();
  } else if (mapId === 'crimson-dojo') {
    // Fire spark
    ctx.shadowBlur = 8;
    ctx.shadowColor = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  } else if (mapId === 'neon-circuit') {
    // Electric spark
    ctx.shadowBlur = 10;
    ctx.shadowColor = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  } else {
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}
