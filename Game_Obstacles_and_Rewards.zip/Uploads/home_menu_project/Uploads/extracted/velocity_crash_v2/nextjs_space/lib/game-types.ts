export type MapId = 'tokyo-night' | 'sakura-pass' | 'neon-circuit' | 'ocean-drive' | 'space-drift' | 'crimson-dojo';

export type Difficulty = 'easy' | 'medium' | 'hard' | 'impossible';
export type ArenaSpeed = 'slow' | 'normal' | 'fast' | 'turbo';
export type BotStyle = 'aggressive' | 'tactical' | 'unpredictable';

export interface MapConfig {
  id: MapId;
  name: string;
  emoji: string;
  bgColor: string;
  accentColor: string;
  secondaryColor: string;
  roadColor: string;
  description: string;
}

export interface GameSettings {
  difficulty: Difficulty;
  arenaSpeed: ArenaSpeed;
  map: MapId;
  botStyle: BotStyle;
  playerColor: string;
}

export interface Obstacle {
  type: 'barrier' | 'oil-slick' | 'speed-burst';
  x: number;
  width: number;
  active: boolean;
  timer: number;
  y: number;
  direction: number;
}

export interface ObstacleEffect {
  type: 'barrier' | 'oil-slick' | 'speed-burst';
  timeLeft: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  opacity: number;
  color: string;
  rotation: number;
  rotationSpeed: number;
  life: number;
  maxLife: number;
}

export interface GameState {
  phase: 'countdown' | 'racing' | 'result';
  countdownValue: number;
  playerPos: number;
  playerVel: number;
  playerBraking: boolean;
  botPos: number;
  botVel: number;
  botBraking: boolean;
  winner: 'player' | 'bot' | 'draw' | null;
  resultType: 'safe' | 'crash' | null;
  playerBrakeTime: number;
  botBrakeTime: number;
  raceStartTime: number;
  elapsed: number;
  playerEffects: ObstacleEffect[];
  botEffects: ObstacleEffect[];
  obstacles: Obstacle[];
  impactText: string | null;
  impactTextTimer: number;
  shakeIntensity: number;
}

export interface GameStats {
  wins: number;
  losses: number;
  draws: number;
  bestBrakeTime: number | null;
  closestDistance: number | null;
  gamesPlayed: number;
}

export const PLAYER_COLORS = [
  '#00e5ff', '#ff3366', '#39ff14', '#ff8c00',
  '#a78bfa', '#ffdd00', '#ff00ff', '#ffffff'
];
