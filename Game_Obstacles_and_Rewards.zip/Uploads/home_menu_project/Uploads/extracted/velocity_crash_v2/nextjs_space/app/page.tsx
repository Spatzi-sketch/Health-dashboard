'use client';

import { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import HomeScreen from '@/components/game/home-screen';
import GameCanvas from '@/components/game/game-canvas';
import ResultScreen from '@/components/game/result-screen';
import TutorialOverlay from '@/components/game/tutorial-overlay';
import { GameSettings, GameState, GameStats } from '@/lib/game-types';
import { getMapConfig } from '@/lib/game-constants';

type AppPhase = 'home' | 'playing' | 'result';

const STATS_KEY = 'velocity_crash_stats';

function loadStats(): GameStats {
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return { wins: 0, losses: 0, draws: 0, bestBrakeTime: null, closestDistance: null, gamesPlayed: 0 };
}

function saveStats(stats: GameStats): void {
  try {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  } catch { /* ignore */ }
}

export default function Page() {
  const [phase, setPhase] = useState<AppPhase>('home');
  const [settings, setSettings] = useState<GameSettings | null>(null);
  const [lastResult, setLastResult] = useState<GameState | null>(null);
  const [gameKey, setGameKey] = useState(0);

  const handleStart = useCallback((s: GameSettings) => {
    setSettings(s);
    setLastResult(null);
    setGameKey((k) => k + 1);
    setPhase('playing');
  }, []);

  const handleResult = useCallback((state: GameState) => {
    setLastResult(state);
    setPhase('result');

    // Update stats
    const stats = loadStats();
    stats.gamesPlayed = (stats.gamesPlayed ?? 0) + 1;
    if (state?.winner === 'player') {
      stats.wins = (stats.wins ?? 0) + 1;
    } else if (state?.winner === 'bot') {
      stats.losses = (stats.losses ?? 0) + 1;
    } else {
      stats.draws = (stats.draws ?? 0) + 1;
    }
    if (state?.playerBrakeTime != null && state.playerBrakeTime > 0) {
      if (stats.bestBrakeTime == null || state.playerBrakeTime > stats.bestBrakeTime) {
        stats.bestBrakeTime = state.playerBrakeTime;
      }
    }
    const gap = Math.max(0, (state?.botPos ?? 1000) - (state?.playerPos ?? 0));
    if (stats.closestDistance == null || gap < stats.closestDistance) {
      stats.closestDistance = gap;
    }
    saveStats(stats);
  }, []);

  const handlePlayAgain = useCallback(() => {
    if (settings) {
      setLastResult(null);
      setGameKey((k) => k + 1);
      setPhase('playing');
    }
  }, [settings]);

  const handleGoHome = useCallback(() => {
    setPhase('home');
    setLastResult(null);
  }, []);

  const mapConfig = settings ? getMapConfig(settings.map) : null;

  return (
    <div className="w-full h-screen overflow-hidden" style={{ background: '#020815' }}>
      <TutorialOverlay />

      <AnimatePresence mode="wait">
        {phase === 'home' && (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full h-full"
          >
            <HomeScreen onStart={handleStart} />
          </motion.div>
        )}

        {(phase === 'playing' || phase === 'result') && settings && (
          <motion.div
            key={`game-${gameKey}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full h-full relative"
          >
            <GameCanvas
              settings={settings}
              onResult={handleResult}
              onBack={handleGoHome}
            />

            {phase === 'result' && lastResult && mapConfig && (
              <ResultScreen
                gameState={lastResult}
                onPlayAgain={handlePlayAgain}
                onChangeSettings={handleGoHome}
                accentColor={mapConfig.accentColor}
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
