'use client';

import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { GameState, GameStats } from '@/lib/game-types';
import { useAudio } from '@/hooks/use-audio';

interface ResultScreenProps {
  gameState: GameState;
  onPlayAgain: () => void;
  onChangeSettings: () => void;
  accentColor: string;
}

export default function ResultScreen({ gameState, onPlayAgain, onChangeSettings, accentColor }: ResultScreenProps) {
  const isWin = gameState?.winner === 'player';
  const isDraw = gameState?.winner === 'draw';
  const isCrash = gameState?.resultType === 'crash';
  const { playSound } = useAudio();
  const sfxPlayedRef = useRef(false);

  useEffect(() => {
    // Play result SFX on mount if not already played by game-canvas
    if (!sfxPlayedRef.current) {
      sfxPlayedRef.current = true;
      // The game-canvas already plays these, so this is a fallback
    }
  }, []);

  const title = isDraw ? 'DRAW!' : isWin ? 'VICTORY!' : 'DEFEAT!';
  const titleColor = isDraw ? '#ffdd00' : isWin ? '#ffd700' : '#ff3333';
  const subtitle = isCrash
    ? isWin
      ? 'You survived the crash!'
      : 'You crashed too hard!'
    : isWin
    ? 'You braked later and lived!'
    : isDraw
    ? 'A perfectly matched race!'
    : 'The bot was more daring!';

  const playerBrakeMs = ((gameState?.playerBrakeTime ?? 0) * 1000).toFixed(0);
  const botBrakeMs = ((gameState?.botBrakeTime ?? 0) * 1000).toFixed(0);
  const gap = Math.max(0, (gameState?.botPos ?? 1000) - (gameState?.playerPos ?? 0));
  const closedPct = Math.min(100, ((1000 - gap) / 1000) * 100).toFixed(1);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', damping: 15, delay: 0.2 }}
        className="max-w-md w-full rounded-2xl p-8 text-center border"
        style={{
          background: 'linear-gradient(135deg, #0a0a1a 0%, #111133 100%)',
          borderColor: titleColor + '44',
        }}
      >
        <motion.h1
          initial={{ scale: 2, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', damping: 10, delay: 0.4 }}
          className="text-5xl font-bold mb-2 tracking-tight font-display"
          style={{ color: titleColor, textShadow: `0 0 30px ${titleColor}88` }}
        >
          {title}
        </motion.h1>

        <p className="text-white/60 text-sm mb-6">{subtitle}</p>

        {isCrash && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mb-4 px-3 py-2 rounded-lg bg-red-900/30 border border-red-500/30"
          >
            <span className="text-red-400 text-sm font-bold">💥 COLLISION</span>
          </motion.div>
        )}

        <div className="grid grid-cols-2 gap-4 mb-6">
          {[
            { label: 'Your Brake', value: `${playerBrakeMs}ms`, highlight: isWin },
            { label: 'Bot Brake', value: `${botBrakeMs}ms`, highlight: !isWin && !isDraw },
            { label: 'Distance Closed', value: `${closedPct}%`, highlight: false },
            { label: 'Final Gap', value: `${Math.round(gap)}u`, highlight: false },
          ].map((item, i) => (
            <motion.div
              key={item.label}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.6 + i * 0.1 }}
              className="rounded-xl p-3 border"
              style={{
                background: item.highlight ? accentColor + '15' : 'rgba(255,255,255,0.05)',
                borderColor: item.highlight ? accentColor + '44' : 'rgba(255,255,255,0.1)',
              }}
            >
              <div className="text-xs text-white/50 mb-1">{item.label}</div>
              <div className="text-lg font-bold text-white font-mono">{item.value}</div>
            </motion.div>
          ))}
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => onPlayAgain?.()}
            className="flex-1 py-3 rounded-xl font-bold text-black transition-all hover:scale-105 active:scale-95"
            style={{ background: `linear-gradient(90deg, ${accentColor}, ${accentColor}cc)` }}
          >
            PLAY AGAIN
          </button>
          <button
            onClick={() => onChangeSettings?.()}
            className="flex-1 py-3 rounded-xl font-bold text-white transition-all hover:scale-105 active:scale-95 bg-white/10 hover:bg-white/20 border border-white/20"
          >
            SETTINGS
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
