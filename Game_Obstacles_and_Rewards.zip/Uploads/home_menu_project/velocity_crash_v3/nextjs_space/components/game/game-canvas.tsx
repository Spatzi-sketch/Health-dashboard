'use client';

import { useRef, useEffect, useCallback, useState } from 'react';
import { GameState, GameSettings, Particle } from '@/lib/game-types';
import { createInitialState, updateGameState } from '@/lib/game-engine';
import { drawMapBackground } from '@/lib/map-renderer';
import { createParticle, updateParticles, drawParticle } from '@/lib/particle-system';
import { drawCar, drawSpeedLines } from '@/lib/car-renderer';
import { drawObstacle } from '@/lib/obstacle-system';
import { getMapConfig, ARENA_WIDTH, BASE_MAX_VELOCITY, SPEED_MULTIPLIERS } from '@/lib/game-constants';
import { useAudio } from '@/hooks/use-audio';

interface GameCanvasProps {
  settings: GameSettings;
  onResult: (state: GameState) => void;
  onBack: () => void;
}

export default function GameCanvas({ settings, onResult, onBack }: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef<GameState | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const brakeInputRef = useRef(false);
  const animFrameRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  const timeRef = useRef<number>(0);
  const countdownTimerRef = useRef<number>(0);
  const resultSentRef = useRef(false);
  const lastCountdownRef = useRef<number>(4);
  const brakeSfxPlayedRef = useRef(false);
  const resultSfxPlayedRef = useRef(false);
  const lastObstacleCountRef = useRef<number>(0);
  const engineStartedRef = useRef(false);
  const [phase, setPhase] = useState<'countdown' | 'racing' | 'result'>('countdown');

  const mapConfig = getMapConfig(settings.map);
  const maxVel = BASE_MAX_VELOCITY * (SPEED_MULTIPLIERS[settings.arenaSpeed] ?? 1);
  const { playSound, startEngine, updateEngineSpeed, stopEngine } = useAudio();

  const initGame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    stateRef.current = createInitialState(settings, canvas.height);
    particlesRef.current = [];
    brakeInputRef.current = false;
    countdownTimerRef.current = 0;
    resultSentRef.current = false;
    lastCountdownRef.current = 4;
    brakeSfxPlayedRef.current = false;
    resultSfxPlayedRef.current = false;
    lastObstacleCountRef.current = 0;
    engineStartedRef.current = false;
    lastTimeRef.current = 0;
    setPhase('countdown');
  }, [settings]);

  useEffect(() => {
    initGame();
    return () => {
      stopEngine();
    };
  }, [initGame, stopEngine]);

  // Input handlers
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.key === ' ') {
        e.preventDefault();
        brakeInputRef.current = true;
      }
      if (e.code === 'Escape') {
        onBack?.();
      }
    };
    const handleTouch = (e: Event) => {
      e.preventDefault();
      brakeInputRef.current = true;
    };
    window.addEventListener('keydown', handleKey);
    window.addEventListener('touchstart', handleTouch, { passive: false });
    window.addEventListener('mousedown', handleTouch);
    return () => {
      window.removeEventListener('keydown', handleKey);
      window.removeEventListener('touchstart', handleTouch);
      window.removeEventListener('mousedown', handleTouch);
    };
  }, [onBack]);

  // Main game loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = canvas.clientWidth * (window.devicePixelRatio ?? 1);
      canvas.height = canvas.clientHeight * (window.devicePixelRatio ?? 1);
      ctx.scale(window.devicePixelRatio ?? 1, window.devicePixelRatio ?? 1);
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const loop = (timestamp: number) => {
      if (!lastTimeRef.current) lastTimeRef.current = timestamp;
      const rawDt = (timestamp - lastTimeRef.current) / 1000;
      const dt = Math.min(rawDt, 0.05); // cap dt
      lastTimeRef.current = timestamp;
      timeRef.current += dt;

      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      let state = stateRef.current;
      if (!state) {
        animFrameRef.current = requestAnimationFrame(loop);
        return;
      }

      // Countdown logic
      if (state.phase === 'countdown') {
        countdownTimerRef.current += dt;
        if (countdownTimerRef.current >= 1) {
          countdownTimerRef.current = 0;
          const newVal = state.countdownValue - 1;
          if (newVal <= 0) {
            state = { ...state, phase: 'racing', raceStartTime: timeRef.current };
            setPhase('racing');
            // Play GO sound
            playSound('countdownGo');
            // Start engine
            if (!engineStartedRef.current) {
              engineStartedRef.current = true;
              startEngine();
              playSound('engineStart');
            }
          } else {
            state = { ...state, countdownValue: newVal };
            // Play countdown beep when value changes
            if (newVal !== lastCountdownRef.current) {
              lastCountdownRef.current = newVal;
              playSound('countdown');
            }
          }
        }
        stateRef.current = state;
      }

      // Racing update
      if (state.phase === 'racing') {
        const prevBraking = state.playerBraking;
        const prevEffectCount = (state.playerEffects ?? []).length;

        state = updateGameState(state, dt, settings, brakeInputRef.current, h);
        stateRef.current = state;

        // Update engine sound frequency based on speed
        updateEngineSpeed(state.playerVel ?? 0);

        // Brake SFX on first brake
        if (!prevBraking && state.playerBraking && !brakeSfxPlayedRef.current) {
          brakeSfxPlayedRef.current = true;
          playSound('brake');
        }

        // Obstacle hit SFX
        const curEffects = state.playerEffects ?? [];
        if (curEffects.length > prevEffectCount) {
          const newest = curEffects[curEffects.length - 1];
          if (newest?.type === 'oil-slick') playSound('oilslick');
          else if (newest?.type === 'speed-burst') playSound('speedburst');
        }

        if (state.phase === 'result') {
          setPhase('result');
          stopEngine();

          // Play result SFX
          if (!resultSfxPlayedRef.current) {
            resultSfxPlayedRef.current = true;
            if (state.resultType === 'crash') {
              playSound('crash');
              setTimeout(() => {
                if (state?.winner === 'player') playSound('win');
                else playSound('lose');
              }, 400);
            } else {
              if (state?.winner === 'player') playSound('win');
              else if (state?.winner === 'bot') playSound('lose');
            }
          }

          if (!resultSentRef.current) {
            resultSentRef.current = true;
            setTimeout(() => onResult?.(state as GameState), 500);
          }
        }
      }

      // Particles
      if (Math.random() < 0.3) {
        particlesRef.current.push(createParticle(settings.map, w, h));
      }
      particlesRef.current = updateParticles(particlesRef.current, dt);
      if (particlesRef.current.length > 200) {
        particlesRef.current = particlesRef.current.slice(-200);
      }

      // --- RENDER ---
      ctx.save();
      // Screen shake
      if ((state.shakeIntensity ?? 0) > 0) {
        const sx = (Math.random() - 0.5) * state.shakeIntensity;
        const sy = (Math.random() - 0.5) * state.shakeIntensity;
        ctx.translate(sx, sy);
      }

      // Background
      drawMapBackground(ctx, settings.map, w, h, timeRef.current);

      // Particles behind cars
      for (const p of particlesRef.current ?? []) {
        drawParticle(ctx, p, settings.map);
      }

      // Road
      const roadY = h * 0.5;
      const roadH = h * 0.18;
      ctx.fillStyle = mapConfig.roadColor;
      ctx.fillRect(0, roadY, w, roadH);

      // Road center line
      ctx.strokeStyle = mapConfig.accentColor + '44';
      ctx.lineWidth = 2;
      ctx.setLineDash([20, 15]);
      ctx.beginPath();
      ctx.moveTo(0, roadY + roadH / 2);
      ctx.lineTo(w, roadY + roadH / 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Road edge glow
      ctx.shadowBlur = 6;
      ctx.shadowColor = mapConfig.accentColor;
      ctx.strokeStyle = mapConfig.accentColor + '33';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, roadY);
      ctx.lineTo(w, roadY);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, roadY + roadH);
      ctx.lineTo(w, roadY + roadH);
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Scale positions to canvas
      const scaleX = w / ARENA_WIDTH;
      const carW = 50;
      const carH = 30;

      // Obstacles
      for (const obs of state.obstacles ?? []) {
        drawObstacle(ctx, obs, scaleX, roadY, roadH);
      }

      // Speed lines
      const playerSpeed = state.playerVel ?? 0;
      drawSpeedLines(ctx, w, h, playerSpeed, maxVel, mapConfig.accentColor);

      // Player car
      const pX = (state.playerPos ?? 0) * scaleX;
      drawCar(ctx, pX, roadY + roadH * 0.2, carW, carH, settings.playerColor, 'right', playerSpeed, maxVel);

      // Bot car
      const bX = (state.botPos ?? ARENA_WIDTH) * scaleX - carW;
      drawCar(ctx, bX, roadY + roadH * 0.2, carW, carH, '#ff3366', 'left', state.botVel ?? 0, maxVel);

      // HUD
      drawHUD(ctx, state, w, h, maxVel, mapConfig.accentColor);

      // Countdown
      if (state.phase === 'countdown') {
        drawCountdown(ctx, state.countdownValue, w, h, mapConfig.accentColor);
      }

      // Impact text
      if (state.impactText && (state.impactTextTimer ?? 0) > 0) {
        drawImpactText(ctx, state.impactText, w, h, state.impactTextTimer ?? 0, mapConfig.accentColor);
      }

      ctx.restore();
      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(animFrameRef.current);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [settings, mapConfig, maxVel, onResult, playSound, startEngine, updateEngineSpeed, stopEngine]);

  return (
    <div className="relative w-full h-full">
      <canvas
        ref={canvasRef}
        className="w-full h-full block cursor-pointer"
        style={{ touchAction: 'none' }}
      />
      {/* Mobile brake button */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 md:hidden">
        <button
          className="px-8 py-3 rounded-xl text-lg font-bold text-white"
          style={{ background: mapConfig.accentColor, opacity: 0.85 }}
          onTouchStart={(e) => {
            e.stopPropagation();
            brakeInputRef.current = true;
          }}
        >
          BRAKE
        </button>
      </div>
      {/* Back button */}
      <button
        onClick={() => onBack?.()}
        className="absolute top-3 left-3 px-3 py-1.5 rounded-lg text-sm font-bold bg-black/50 text-white hover:bg-black/70 transition-colors border border-white/20"
      >
        ← BACK
      </button>
    </div>
  );
}

function drawHUD(ctx: CanvasRenderingContext2D, state: GameState, w: number, h: number, maxVel: number, accent: string): void {
  const speed = state.playerVel ?? 0;
  const speedPct = Math.min(1, speed / Math.max(1, maxVel));

  // Speed bar
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(20, h - 50, 200, 20);
  const barColor = speedPct > 0.8 ? '#ff3333' : speedPct > 0.5 ? '#ffaa00' : accent;
  ctx.fillStyle = barColor;
  ctx.fillRect(20, h - 50, 200 * speedPct, 20);
  ctx.strokeStyle = '#ffffff33';
  ctx.lineWidth = 1;
  ctx.strokeRect(20, h - 50, 200, 20);

  // Speed text
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 14px monospace';
  ctx.fillText(`${Math.round(speed)} u/s`, 230, h - 35);

  // Brake status
  if (state.playerBraking) {
    ctx.fillStyle = '#ff3333';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText('BRAKING', 20, h - 60);
  }

  // Timer
  ctx.fillStyle = '#ffffffaa';
  ctx.font = '14px monospace';
  ctx.textAlign = 'right';
  ctx.fillText(`${(state.elapsed ?? 0).toFixed(2)}s`, w - 20, 30);
  ctx.textAlign = 'left';

  // Gap indicator
  const gap = (state.botPos ?? 1000) - (state.playerPos ?? 0);
  ctx.fillStyle = gap < 100 ? '#ff3333' : '#ffffffaa';
  ctx.font = '12px monospace';
  ctx.textAlign = 'right';
  ctx.fillText(`Gap: ${Math.round(gap)}`, w - 20, 50);
  ctx.textAlign = 'left';

  // Active effects
  const effects = state.playerEffects ?? [];
  if (effects.length > 0) {
    ctx.font = 'bold 12px sans-serif';
    effects.forEach((e: any, i: number) => {
      ctx.fillStyle = e.type === 'oil-slick' ? '#aa44ff' : e.type === 'barrier' ? '#ff4400' : '#ffdd00';
      ctx.fillText(`${(e.type ?? 'effect').toUpperCase()} ${(e.timeLeft ?? 0).toFixed(1)}s`, 20, 30 + i * 18);
    });
  }
}

function drawCountdown(ctx: CanvasRenderingContext2D, value: number, w: number, h: number, accent: string): void {
  ctx.save();
  ctx.fillStyle = 'rgba(0,0,0,0.4)';
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = accent;
  ctx.shadowBlur = 30;
  ctx.shadowColor = accent;
  ctx.font = 'bold 120px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(String(value), w / 2, h / 2);
  ctx.shadowBlur = 0;
  ctx.restore();
}

function drawImpactText(ctx: CanvasRenderingContext2D, text: string, w: number, h: number, timer: number, accent: string): void {
  ctx.save();
  const scale = 1 + (1 - Math.min(1, timer)) * 0.5;
  ctx.translate(w / 2, h * 0.3);
  ctx.scale(scale, scale);
  ctx.font = 'bold 64px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.globalAlpha = Math.min(1, timer * 2);

  // Outline
  ctx.strokeStyle = '#000';
  ctx.lineWidth = 6;
  ctx.strokeText(text, 0, 0);

  // Fill
  const color = text === 'VICTORY!' ? '#ffd700' : text === 'CRASH!' || text === 'DEFEAT!' ? '#ff3333' : accent;
  ctx.fillStyle = color;
  ctx.shadowBlur = 20;
  ctx.shadowColor = color;
  ctx.fillText(text, 0, 0);
  ctx.shadowBlur = 0;
  ctx.restore();
}
