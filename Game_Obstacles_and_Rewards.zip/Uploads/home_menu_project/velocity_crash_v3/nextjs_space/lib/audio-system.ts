/* eslint-disable @typescript-eslint/no-explicit-any */

import { MapId } from './game-types';

const AUDIO_PREFS_KEY = 'velocity_crash_audio';

interface AudioPrefs {
  musicVolume: number;
  sfxVolume: number;
  muted: boolean;
}

function loadPrefs(): AudioPrefs {
  try {
    const raw = localStorage?.getItem?.(AUDIO_PREFS_KEY);
    if (raw) {
      const p = JSON.parse(raw);
      return {
        musicVolume: typeof p?.musicVolume === 'number' ? p.musicVolume : 0.5,
        sfxVolume: typeof p?.sfxVolume === 'number' ? p.sfxVolume : 0.7,
        muted: !!p?.muted,
      };
    }
  } catch { /* ignore */ }
  return { musicVolume: 0.5, sfxVolume: 0.7, muted: false };
}

function savePrefs(p: AudioPrefs): void {
  try {
    localStorage?.setItem?.(AUDIO_PREFS_KEY, JSON.stringify(p));
  } catch { /* ignore */ }
}

// Note frequencies
const NOTE: Record<string, number> = {
  'F#1': 46.25, 'G1': 49.00, 'A1': 55.00, 'B1': 61.74,
  'C#2': 69.30, 'D2': 73.42, 'E1': 41.20, 'E2': 82.41,
  'F#2': 92.50, 'G2': 98.00, 'A2': 110.00, 'B2': 123.47,
  'C#3': 138.59, 'D3': 146.83, 'E3': 164.81, 'F#3': 185.00,
  'G3': 196.00, 'A3': 220.00, 'B3': 246.94,
  'C4': 261.63, 'D4': 293.66, 'E4': 329.63, 'F#4': 369.99,
  'G4': 392.00, 'A4': 440.00, 'B4': 493.88,
  'C#5': 554.37, 'D5': 587.33, 'G5': 783.99,
  'F#5': 739.99,
};

class AudioSystem {
  private ctx: AudioContext | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private masterGain: GainNode | null = null;
  private activeNodes: AudioNode[] = [];
  private musicInterval: any = null;
  private musicTimeout: any = null;
  private prefs: AudioPrefs;
  private playing = false;
  private currentMap: MapId | null = null;
  private engineOsc: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private scheduledTimeouts: any[] = [];

  constructor() {
    this.prefs = loadPrefs();
  }

  private ensureContext(): AudioContext | null {
    try {
      if (!this.ctx) {
        this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        this.masterGain = this.ctx.createGain();
        this.masterGain.connect(this.ctx.destination);
        this.masterGain.gain.value = this.prefs.muted ? 0 : 1;

        this.musicGain = this.ctx.createGain();
        this.musicGain.connect(this.masterGain);
        this.musicGain.gain.value = this.prefs.musicVolume;

        this.sfxGain = this.ctx.createGain();
        this.sfxGain.connect(this.masterGain);
        this.sfxGain.gain.value = this.prefs.sfxVolume;
      }
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      return this.ctx;
    } catch {
      return null;
    }
  }

  // ---- Volume / Mute ----
  setMusicVolume(v: number): void {
    this.prefs.musicVolume = Math.max(0, Math.min(1, v));
    try { if (this.musicGain) this.musicGain.gain.value = this.prefs.musicVolume; } catch { /* */ }
    savePrefs(this.prefs);
  }

  setSfxVolume(v: number): void {
    this.prefs.sfxVolume = Math.max(0, Math.min(1, v));
    try { if (this.sfxGain) this.sfxGain.gain.value = this.prefs.sfxVolume; } catch { /* */ }
    savePrefs(this.prefs);
  }

  getMusicVolume(): number { return this.prefs.musicVolume; }
  getSfxVolume(): number { return this.prefs.sfxVolume; }
  isMuted(): boolean { return this.prefs.muted; }

  setMuted(b: boolean): void {
    this.prefs.muted = b;
    try { if (this.masterGain) this.masterGain.gain.value = b ? 0 : 1; } catch { /* */ }
    savePrefs(this.prefs);
  }

  toggleMute(): boolean {
    this.setMuted(!this.prefs.muted);
    return this.prefs.muted;
  }

  // ---- Helpers ----
  private track(node: AudioNode): AudioNode {
    this.activeNodes.push(node);
    return node;
  }

  private makeOsc(ctx: AudioContext, type: OscillatorType, freq: number, dest: AudioNode, startTime: number, endTime: number, gainVal = 0.3): { osc: OscillatorNode; gain: GainNode } {
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.value = gainVal;
    osc.connect(g);
    g.connect(dest);
    this.track(osc);
    this.track(g);
    try {
      osc.start(startTime);
      osc.stop(endTime);
    } catch { /* */ }
    return { osc, gain: g };
  }

  private makeNoise(ctx: AudioContext, duration: number, dest: AudioNode, startTime: number, gainVal = 0.1): { source: AudioBufferSourceNode; gain: GainNode } {
    const bufferSize = Math.max(1, Math.floor(ctx.sampleRate * duration));
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    const g = ctx.createGain();
    g.gain.value = gainVal;
    source.connect(g);
    g.connect(dest);
    this.track(source);
    this.track(g);
    try {
      source.start(startTime);
      source.stop(startTime + duration);
    } catch { /* */ }
    return { source, gain: g };
  }

  private createReverb(ctx: AudioContext, duration: number, decay: number): ConvolverNode {
    const length = Math.max(1, Math.floor(ctx.sampleRate * duration));
    const impulse = ctx.createBuffer(2, length, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const data = impulse.getChannelData(ch);
      for (let i = 0; i < length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
      }
    }
    const conv = ctx.createConvolver();
    conv.buffer = impulse;
    return conv;
  }

  // ---- Music Patterns ----
  playMapMusic(mapId: MapId): void {
    this.stopMusic();
    const ctx = this.ensureContext();
    if (!ctx || !this.musicGain) return;
    this.currentMap = mapId;
    this.playing = true;

    switch (mapId) {
      case 'tokyo-night': this.playTokyoNight(ctx); break;
      case 'sakura-pass': this.playSakuraPass(ctx); break;
      case 'neon-circuit': this.playNeonCircuit(ctx); break;
      case 'ocean-drive': this.playOceanDrive(ctx); break;
      case 'space-drift': this.playSpaceDrift(ctx); break;
      case 'crimson-dojo': this.playCrimsonDojo(ctx); break;
      default: this.playTokyoNight(ctx); break;
    }
  }

  private scheduleLoop(fn: () => void, intervalMs: number): void {
    fn();
    this.musicInterval = setInterval(() => {
      if (this.playing) fn();
    }, intervalMs);
  }

  // Tokyo Night - Synthwave BPM 115
  private playTokyoNight(ctx: AudioContext): void {
    const bpm = 115;
    const beat = 60 / bpm;
    const bar = beat * 4;
    const dest = this.musicGain!;

    // Pad - sustained detuned sines
    const padGain = ctx.createGain();
    padGain.gain.value = 0.06;
    padGain.connect(dest);
    this.track(padGain);

    const padFreqs = [NOTE['A2'], NOTE['E3']];
    for (const freq of padFreqs) {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const osc2 = ctx.createOscillator();
      osc2.type = 'sine';
      osc2.frequency.value = freq * 1.005;
      osc.connect(padGain);
      osc2.connect(padGain);
      this.track(osc);
      this.track(osc2);
      try { osc.start(); osc2.start(); } catch { /* */ }

      // LFO tremolo
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.5;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 0.03;
      lfo.connect(lfoGain);
      lfoGain.connect(padGain.gain);
      this.track(lfo);
      this.track(lfoGain);
      try { lfo.start(); } catch { /* */ }
    }

    // Reverb
    const reverb = this.createReverb(ctx, 2, 3);
    reverb.connect(dest);
    this.track(reverb);

    // Delay for arp echo
    const delay = ctx.createDelay(1);
    delay.delayTime.value = 0.3;
    const feedback = ctx.createGain();
    feedback.gain.value = 0.3;
    delay.connect(feedback);
    feedback.connect(delay);
    delay.connect(dest);
    this.track(delay);
    this.track(feedback);

    const arpNotes = [NOTE['A3'], NOTE['C4'], NOTE['E4'], NOTE['G4'], NOTE['A4']];
    const bassFreq = NOTE['A1'];

    this.scheduleLoop(() => {
      if (!this.playing) return;
      const now = ctx.currentTime;
      // Bass - pulsing on 16th notes
      for (let i = 0; i < 16; i++) {
        const t = now + i * (beat / 4);
        const { osc, gain } = this.makeOsc(ctx, 'sawtooth', bassFreq, dest, t, t + beat / 5, 0.12);
        gain.gain.setValueAtTime(0.12, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + beat / 5);
      }
      // Arpeggio synth
      for (let i = 0; i < 16; i++) {
        const t = now + i * (beat / 4);
        const note = arpNotes[i % arpNotes.length];
        const osc = ctx.createOscillator();
        osc.type = (i % 2 === 0) ? 'sawtooth' : 'square';
        osc.frequency.value = note;
        const g = ctx.createGain();
        g.gain.value = 0;
        g.gain.setValueAtTime(0.08, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + beat / 3);
        osc.connect(g);
        g.connect(reverb);
        g.connect(delay);
        this.track(osc);
        this.track(g);
        try { osc.start(t); osc.stop(t + beat / 2); } catch { /* */ }
      }
    }, bar * 1000);
  }

  // Sakura Pass - Japanese Ambient BPM 80
  private playSakuraPass(ctx: AudioContext): void {
    const bpm = 80;
    const beat = 60 / bpm;
    const bar = beat * 4;
    const dest = this.musicGain!;

    // Ambient pad
    const padGain = ctx.createGain();
    padGain.gain.value = 0.05;
    padGain.connect(dest);
    this.track(padGain);
    const padOsc = ctx.createOscillator();
    padOsc.type = 'sine';
    padOsc.frequency.value = NOTE['D3'];
    padOsc.connect(padGain);
    this.track(padOsc);
    try { padOsc.start(); } catch { /* */ }
    // Tremolo
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.3;
    const lfoG = ctx.createGain();
    lfoG.gain.value = 0.02;
    lfo.connect(lfoG);
    lfoG.connect(padGain.gain);
    this.track(lfo);
    this.track(lfoG);
    try { lfo.start(); } catch { /* */ }

    const pentatonic = [NOTE['D4'], NOTE['E4'], NOTE['F#4'], NOTE['A4'], NOTE['B4']];
    let highNoteCounter = 0;

    this.scheduleLoop(() => {
      if (!this.playing) return;
      const now = ctx.currentTime;
      // Bell/koto notes - triangle with fast attack slow decay
      for (let i = 0; i < 4; i++) {
        const t = now + i * beat;
        const note = pentatonic[Math.floor(Math.random() * pentatonic.length)];
        const osc = ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.value = note;
        const g = ctx.createGain();
        g.gain.value = 0;
        g.gain.setValueAtTime(0.12, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + beat * 1.5);
        osc.connect(g);
        g.connect(dest);
        this.track(osc);
        this.track(g);
        try { osc.start(t); osc.stop(t + beat * 2); } catch { /* */ }
      }
      // High sparse note every 2-3 beats
      highNoteCounter++;
      if (highNoteCounter % 3 === 0) {
        const t = now + beat * 2;
        const osc = ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.value = NOTE['D5'];
        const g = ctx.createGain();
        g.gain.value = 0;
        g.gain.setValueAtTime(0.06, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + beat * 3);
        osc.connect(g);
        g.connect(dest);
        this.track(osc);
        this.track(g);
        try { osc.start(t); osc.stop(t + beat * 4); } catch { /* */ }
      }
    }, bar * 1000);
  }

  // Neon Circuit - Hard Techno BPM 140
  private playNeonCircuit(ctx: AudioContext): void {
    const bpm = 140;
    const beat = 60 / bpm;
    const bar = beat * 4;
    const dest = this.musicGain!;

    // Distortion
    const distortion = ctx.createWaveShaper();
    const curve = new Float32Array(256);
    for (let i = 0; i < 256; i++) {
      const x = (i * 2) / 256 - 1;
      curve[i] = (Math.PI + 40) * x / (Math.PI + 40 * Math.abs(x));
    }
    distortion.curve = curve;
    distortion.connect(dest);
    this.track(distortion);

    this.scheduleLoop(() => {
      if (!this.playing) return;
      const now = ctx.currentTime;

      // Kick drum on every beat
      for (let i = 0; i < 4; i++) {
        const t = now + i * beat;
        const osc = ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(NOTE['E2'], t);
        osc.frequency.exponentialRampToValueAtTime(NOTE['E1'], t + 0.1);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.3, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
        osc.connect(g);
        g.connect(dest);
        this.track(osc);
        this.track(g);
        try { osc.start(t); osc.stop(t + 0.2); } catch { /* */ }
      }

      // Bass on off-beats
      for (let i = 0; i < 4; i++) {
        const t = now + i * beat + beat / 2;
        const { gain } = this.makeOsc(ctx, 'sawtooth', NOTE['E2'], distortion, t, t + beat / 3, 0.1);
        gain.gain.setValueAtTime(0.1, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + beat / 3);
      }

      // Synth stab on beats 2 and 4
      for (const bi of [1, 3]) {
        const t = now + bi * beat;
        const chordFreqs = [NOTE['E3'], NOTE['G3'], NOTE['B3']];
        for (const freq of chordFreqs) {
          const { gain } = this.makeOsc(ctx, 'square', freq, dest, t, t + beat / 2, 0.04);
          gain.gain.setValueAtTime(0.04, t);
          gain.gain.exponentialRampToValueAtTime(0.001, t + beat / 2);
        }
      }

      // Hi-hat noise every 8th note
      for (let i = 0; i < 8; i++) {
        const t = now + i * (beat / 2);
        const bufSize = Math.max(1, Math.floor(ctx.sampleRate * 0.03));
        const buf = ctx.createBuffer(1, bufSize, ctx.sampleRate);
        const d = buf.getChannelData(0);
        for (let j = 0; j < bufSize; j++) d[j] = Math.random() * 2 - 1;
        const src = ctx.createBufferSource();
        src.buffer = buf;
        const bp = ctx.createBiquadFilter();
        bp.type = 'bandpass';
        bp.frequency.value = 8000;
        bp.Q.value = 2;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.06, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.03);
        src.connect(bp);
        bp.connect(g);
        g.connect(dest);
        this.track(src);
        this.track(bp);
        this.track(g);
        try { src.start(t); src.stop(t + 0.05); } catch { /* */ }
      }
    }, bar * 1000);
  }

  // Ocean Drive - Tropical Lo-fi BPM 95
  private playOceanDrive(ctx: AudioContext): void {
    const bpm = 95;
    const beat = 60 / bpm;
    const bar = beat * 4;
    const dest = this.musicGain!;

    // Chord pad - detuned sines G3/B3/D4
    const chordGain = ctx.createGain();
    chordGain.gain.value = 0;
    chordGain.connect(dest);
    this.track(chordGain);

    const chordFreqs = [NOTE['G3'], NOTE['B3'], NOTE['D4']];
    for (const freq of chordFreqs) {
      for (let d = 0; d < 3; d++) {
        const osc = ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.value = freq * (1 + (d - 1) * 0.003);
        osc.connect(chordGain);
        this.track(osc);
        try { osc.start(); } catch { /* */ }
      }
    }
    // Slow attack for pad
    try {
      chordGain.gain.setValueAtTime(0, ctx.currentTime);
      chordGain.gain.linearRampToValueAtTime(0.04, ctx.currentTime + 2);
    } catch { /* */ }

    const melody = [NOTE['G4'], NOTE['A4'], NOTE['B4'], NOTE['D5']];
    let melIdx = 0;

    this.scheduleLoop(() => {
      if (!this.playing) return;
      const now = ctx.currentTime;

      // Bass - sine G2 on beat 1, D2 on beat 3
      const bassNotes = [NOTE['G2'], 0, NOTE['D2'], 0];
      for (let i = 0; i < 4; i++) {
        if (bassNotes[i] === 0) continue;
        const t = now + i * beat;
        const { gain } = this.makeOsc(ctx, 'sine', bassNotes[i], dest, t, t + beat * 0.8, 0.15);
        gain.gain.setValueAtTime(0.15, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + beat * 0.8);
      }

      // Snare-like noise on beat 2 and 4
      for (const bi of [1, 3]) {
        const t = now + bi * beat;
        const { gain } = this.makeNoise(ctx, 0.1, dest, t, 0.06);
        gain.gain.setValueAtTime(0.06, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
      }

      // Melody notes with vibrato
      for (let i = 0; i < 2; i++) {
        const t = now + i * beat * 2 + beat;
        const note = melody[melIdx % melody.length];
        melIdx++;
        const osc = ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.value = note;
        // Vibrato
        const vib = ctx.createOscillator();
        vib.frequency.value = 5;
        const vibG = ctx.createGain();
        vibG.gain.value = 2;
        vib.connect(vibG);
        vibG.connect(osc.frequency);
        const g = ctx.createGain();
        g.gain.value = 0;
        g.gain.setValueAtTime(0.07, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + beat * 1.5);
        osc.connect(g);
        g.connect(dest);
        this.track(osc);
        this.track(g);
        this.track(vib);
        this.track(vibG);
        try { osc.start(t); osc.stop(t + beat * 2); vib.start(t); vib.stop(t + beat * 2); } catch { /* */ }
      }
    }, bar * 1000);
  }

  // Space Drift - Cosmic Ambient BPM 60
  private playSpaceDrift(ctx: AudioContext): void {
    const bpm = 60;
    const beat = 60 / bpm;
    const bar = beat * 4;
    const dest = this.musicGain!;

    // Deep drone
    const droneGain = ctx.createGain();
    droneGain.gain.value = 0.08;
    droneGain.connect(dest);
    this.track(droneGain);
    const drone = ctx.createOscillator();
    drone.type = 'sine';
    drone.frequency.value = NOTE['F#1'];
    drone.connect(droneGain);
    this.track(drone);
    try { drone.start(); } catch { /* */ }
    // Very slow LFO on frequency
    const droneLfo = ctx.createOscillator();
    droneLfo.frequency.value = 0.08;
    const droneLfoG = ctx.createGain();
    droneLfoG.gain.value = 2;
    droneLfo.connect(droneLfoG);
    droneLfoG.connect(drone.frequency);
    this.track(droneLfo);
    this.track(droneLfoG);
    try { droneLfo.start(); } catch { /* */ }

    // Evolving pad - 4 detuned oscs with filter sweep
    const padFreqs = [NOTE['F#2'], NOTE['C#3'], NOTE['A3'], NOTE['F#3']];
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 400;
    filter.Q.value = 2;
    filter.connect(dest);
    this.track(filter);

    // LFO on filter cutoff
    const filterLfo = ctx.createOscillator();
    filterLfo.frequency.value = 0.05;
    const filterLfoG = ctx.createGain();
    filterLfoG.gain.value = 300;
    filterLfo.connect(filterLfoG);
    filterLfoG.connect(filter.frequency);
    this.track(filterLfo);
    this.track(filterLfoG);
    try { filterLfo.start(); } catch { /* */ }

    for (const freq of padFreqs) {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const osc2 = ctx.createOscillator();
      osc2.type = 'sine';
      osc2.frequency.value = freq * 1.003;
      const g = ctx.createGain();
      g.gain.value = 0.03;
      osc.connect(g);
      osc2.connect(g);
      g.connect(filter);
      this.track(osc);
      this.track(osc2);
      this.track(g);
      try { osc.start(); osc2.start(); } catch { /* */ }
    }

    // Long reverb
    const reverb = this.createReverb(ctx, 4, 2);
    reverb.connect(dest);
    this.track(reverb);

    const arpNotes = [NOTE['F#4'], NOTE['A4'], NOTE['C#5']];
    let arpIdx = 0;

    this.scheduleLoop(() => {
      if (!this.playing) return;
      const now = ctx.currentTime;
      // Sparse arpeggio every 2 beats
      for (let i = 0; i < 2; i++) {
        const t = now + i * beat * 2;
        const note = arpNotes[arpIdx % arpNotes.length];
        arpIdx++;
        const osc = ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.value = note;
        const g = ctx.createGain();
        g.gain.value = 0;
        g.gain.setValueAtTime(0.05, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + beat * 3);
        osc.connect(g);
        g.connect(reverb);
        this.track(osc);
        this.track(g);
        try { osc.start(t); osc.stop(t + beat * 4); } catch { /* */ }
      }
    }, bar * 1000);
  }

  // Crimson Dojo - Battle Music BPM 160
  private playCrimsonDojo(ctx: AudioContext): void {
    const bpm = 160;
    const beat = 60 / bpm;
    const bar = beat * 4;
    const dest = this.musicGain!;

    // Distortion for bass
    const dist = ctx.createWaveShaper();
    const c2 = new Float32Array(256);
    for (let i = 0; i < 256; i++) {
      const x = (i * 2) / 256 - 1;
      c2[i] = (Math.PI + 50) * x / (Math.PI + 50 * Math.abs(x));
    }
    dist.curve = c2;
    dist.connect(dest);
    this.track(dist);

    this.scheduleLoop(() => {
      if (!this.playing) return;
      const now = ctx.currentTime;

      // Taiko on beats 1 and 3
      for (const bi of [0, 2]) {
        const t = now + bi * beat;
        const osc = ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(NOTE['B2'], t);
        osc.frequency.exponentialRampToValueAtTime(NOTE['B1'], t + 0.08);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.35, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
        osc.connect(g);
        g.connect(dest);
        this.track(osc);
        this.track(g);
        try { osc.start(t); osc.stop(t + 0.25); } catch { /* */ }
      }

      // Aggressive bass - 16th note pump
      for (let i = 0; i < 16; i++) {
        const t = now + i * (beat / 4);
        const { gain } = this.makeOsc(ctx, 'sawtooth', NOTE['B2'], dist, t, t + beat / 5, 0.08);
        gain.gain.setValueAtTime(0.08, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + beat / 5);
      }

      // Power chord on bar downbeat
      const chordT = now;
      const chordFreqs = [NOTE['B2'], NOTE['D3'], NOTE['F#3']];
      for (const freq of chordFreqs) {
        const { gain } = this.makeOsc(ctx, 'square', freq, dest, chordT, chordT + beat, 0.04);
        gain.gain.setValueAtTime(0.04, chordT);
        gain.gain.exponentialRampToValueAtTime(0.001, chordT + beat);
      }

      // Cymbal on beats 2 and 4
      for (const bi of [1, 3]) {
        const t = now + bi * beat;
        const { gain } = this.makeNoise(ctx, 0.15, dest, t, 0.04);
        const hp = ctx.createBiquadFilter();
        hp.type = 'highpass';
        hp.frequency.value = 6000;
        this.track(hp);
        // rewire through filter
        gain.disconnect();
        gain.connect(hp);
        hp.connect(dest);
        gain.gain.setValueAtTime(0.04, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
      }
    }, bar * 1000);
  }

  // ---- SFX ----
  playSound(name: string): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    try {
      switch (name) {
        case 'countdown': this.sfxCountdown(ctx); break;
        case 'countdownGo': this.sfxCountdownGo(ctx); break;
        case 'brake': this.sfxBrake(ctx); break;
        case 'crash': this.sfxCrash(ctx); break;
        case 'win': this.sfxWin(ctx); break;
        case 'lose': this.sfxLose(ctx); break;
        case 'speedburst': this.sfxSpeedburst(ctx); break;
        case 'oilslick': this.sfxOilslick(ctx); break;
        case 'engineStart': this.sfxEngineStart(ctx); break;
        default: break;
      }
    } catch { /* */ }
  }

  private sfxCountdown(ctx: AudioContext): void {
    const t = ctx.currentTime;
    this.makeOsc(ctx, 'sine', 880, this.sfxGain!, t, t + 0.05, 0.2);
  }

  private sfxCountdownGo(ctx: AudioContext): void {
    const t = ctx.currentTime;
    this.makeOsc(ctx, 'sine', 1760, this.sfxGain!, t, t + 0.1, 0.25);
  }

  private sfxBrake(ctx: AudioContext): void {
    const t = ctx.currentTime;
    const dur = 0.3;
    const { source, gain: g } = this.makeNoise(ctx, dur, this.sfxGain!, t, 0.15);
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(800, t);
    bp.frequency.linearRampToValueAtTime(200, t + dur);
    bp.Q.value = 5;
    // rewire
    g.disconnect();
    source.disconnect();
    source.connect(bp);
    bp.connect(g);
    g.connect(this.sfxGain!);
    this.track(bp);
  }

  private sfxCrash(ctx: AudioContext): void {
    const t = ctx.currentTime;
    const dur = 0.6;
    const { source, gain: g } = this.makeNoise(ctx, dur, this.sfxGain!, t, 0.25);
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 200;
    source.disconnect();
    source.connect(lp);
    lp.connect(g);
    g.disconnect();
    g.connect(this.sfxGain!);
    g.gain.setValueAtTime(0.25, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    this.track(lp);
  }

  private sfxWin(ctx: AudioContext): void {
    const t = ctx.currentTime;
    const notes = [NOTE['G4'], NOTE['B4'], NOTE['D5'], NOTE['G5']];
    const reverb = this.createReverb(ctx, 1.5, 3);
    reverb.connect(this.sfxGain!);
    this.track(reverb);
    notes.forEach((freq, i) => {
      const st = t + i * 0.08;
      const { gain } = this.makeOsc(ctx, 'triangle', freq, reverb, st, st + 0.3, 0.15);
      gain.gain.setValueAtTime(0.15, st);
      gain.gain.exponentialRampToValueAtTime(0.001, st + 0.3);
    });
  }

  private sfxLose(ctx: AudioContext): void {
    const t = ctx.currentTime;
    const notes = [NOTE['G4'], NOTE['E4'], NOTE['C4'], NOTE['G3']];
    notes.forEach((freq, i) => {
      const st = t + i * 0.08;
      const { gain } = this.makeOsc(ctx, 'triangle', freq, this.sfxGain!, st, st + 0.3, 0.12);
      gain.gain.setValueAtTime(0.12, st);
      gain.gain.exponentialRampToValueAtTime(0.001, st + 0.3);
    });
  }

  private sfxSpeedburst(ctx: AudioContext): void {
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(200, t);
    osc.frequency.linearRampToValueAtTime(800, t + 0.2);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.1, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    osc.connect(g);
    g.connect(this.sfxGain!);
    this.track(osc);
    this.track(g);
    try { osc.start(t); osc.stop(t + 0.25); } catch { /* */ }
  }

  private sfxOilslick(ctx: AudioContext): void {
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = 300;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 8;
    const lfoG = ctx.createGain();
    lfoG.gain.value = 50;
    lfo.connect(lfoG);
    lfoG.connect(osc.frequency);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.12, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    osc.connect(g);
    g.connect(this.sfxGain!);
    this.track(osc);
    this.track(g);
    this.track(lfo);
    this.track(lfoG);
    try { osc.start(t); osc.stop(t + 0.25); lfo.start(t); lfo.stop(t + 0.25); } catch { /* */ }
  }

  private sfxEngineStart(ctx: AudioContext): void {
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(100, t);
    osc.frequency.linearRampToValueAtTime(200, t + 0.3);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.08, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    osc.connect(g);
    g.connect(this.sfxGain!);
    this.track(osc);
    this.track(g);
    try { osc.start(t); osc.stop(t + 0.35); } catch { /* */ }
  }

  // ---- Engine Sound ----
  startEngine(): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain || this.engineOsc) return;
    try {
      this.engineOsc = ctx.createOscillator();
      this.engineOsc.type = 'sawtooth';
      this.engineOsc.frequency.value = 60;
      this.engineGain = ctx.createGain();
      this.engineGain.gain.value = 0.03;
      this.engineOsc.connect(this.engineGain);
      this.engineGain.connect(this.sfxGain);
      this.engineOsc.start();
    } catch { /* */ }
  }

  updateEngineSpeed(speed: number): void {
    try {
      if (this.engineOsc) {
        this.engineOsc.frequency.value = 60 + speed * 0.3;
      }
    } catch { /* */ }
  }

  stopEngine(): void {
    try {
      this.engineOsc?.stop();
    } catch { /* */ }
    this.engineOsc = null;
    this.engineGain = null;
  }

  // ---- Music control ----
  stopMusic(): void {
    this.playing = false;
    this.currentMap = null;
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
    if (this.musicTimeout) {
      clearTimeout(this.musicTimeout);
      this.musicTimeout = null;
    }
    for (const t of this.scheduledTimeouts) {
      try { clearTimeout(t); } catch { /* */ }
    }
    this.scheduledTimeouts = [];
    // Disconnect all tracked nodes
    for (const node of this.activeNodes) {
      try {
        if (node instanceof OscillatorNode || node instanceof AudioBufferSourceNode) {
          (node as any).stop?.();
        }
        node.disconnect();
      } catch { /* */ }
    }
    this.activeNodes = [];
    this.stopEngine();
    // Recreate gain nodes
    if (this.ctx && this.masterGain) {
      try {
        this.musicGain = this.ctx.createGain();
        this.musicGain.connect(this.masterGain);
        this.musicGain.gain.value = this.prefs.musicVolume;
        this.sfxGain = this.ctx.createGain();
        this.sfxGain.connect(this.masterGain);
        this.sfxGain.gain.value = this.prefs.sfxVolume;
      } catch { /* */ }
    }
  }

  pauseMusic(): void {
    try { this.ctx?.suspend(); } catch { /* */ }
  }

  resumeMusic(): void {
    try { this.ctx?.resume(); } catch { /* */ }
  }

  init(): void {
    this.ensureContext();
  }
}

// Singleton
let instance: AudioSystem | null = null;

export function getAudioSystem(): AudioSystem {
  if (!instance) {
    instance = new AudioSystem();
  }
  return instance;
}

export type { AudioSystem };
