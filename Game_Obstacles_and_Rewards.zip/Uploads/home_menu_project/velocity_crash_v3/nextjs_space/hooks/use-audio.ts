'use client';

import { useRef, useCallback, useState, useEffect } from 'react';
import { getAudioSystem, AudioSystem } from '@/lib/audio-system';
import { MapId } from '@/lib/game-types';

export function useAudio() {
  const systemRef = useRef<AudioSystem | null>(null);
  const [muted, setMutedState] = useState(false);
  const [musicVolume, setMusicVolumeState] = useState(0.5);

  useEffect(() => {
    const sys = getAudioSystem();
    systemRef.current = sys;
    setMutedState(sys.isMuted());
    setMusicVolumeState(sys.getMusicVolume());
  }, []);

  const playMapMusic = useCallback((mapId: MapId) => {
    systemRef.current?.playMapMusic(mapId);
  }, []);

  const stopMusic = useCallback(() => {
    systemRef.current?.stopMusic();
  }, []);

  const playSound = useCallback((name: string) => {
    systemRef.current?.playSound(name);
  }, []);

  const setMusicVolume = useCallback((v: number) => {
    systemRef.current?.setMusicVolume(v);
    setMusicVolumeState(v);
  }, []);

  const setSfxVolume = useCallback((v: number) => {
    systemRef.current?.setSfxVolume(v);
  }, []);

  const toggleMute = useCallback(() => {
    const newVal = systemRef.current?.toggleMute() ?? false;
    setMutedState(newVal);
    return newVal;
  }, []);

  const startEngine = useCallback(() => {
    systemRef.current?.startEngine();
  }, []);

  const updateEngineSpeed = useCallback((speed: number) => {
    systemRef.current?.updateEngineSpeed(speed);
  }, []);

  const stopEngine = useCallback(() => {
    systemRef.current?.stopEngine();
  }, []);

  return {
    playMapMusic,
    stopMusic,
    playSound,
    setMusicVolume,
    setSfxVolume,
    toggleMute,
    startEngine,
    updateEngineSpeed,
    stopEngine,
    isMuted: muted,
    musicVolume,
  };
}
