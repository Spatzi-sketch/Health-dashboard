'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const TUTORIAL_KEY = 'velocity_crash_tutorial_seen';

export default function TutorialOverlay() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    try {
      const seen = localStorage.getItem(TUTORIAL_KEY);
      if (!seen) setShow(true);
    } catch {
      // ignore
    }
  }, []);

  const dismiss = () => {
    setShow(false);
    try {
      localStorage.setItem(TUTORIAL_KEY, 'true');
    } catch {
      // ignore
    }
  };

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: 'spring', damping: 20 }}
            className="max-w-lg w-full rounded-2xl border border-cyan-500/30 p-8 text-center"
            style={{ background: 'linear-gradient(135deg, #050b18 0%, #0a1530 100%)' }}
          >
            <h2 className="text-4xl font-bold text-cyan-400 mb-6 tracking-tight font-display">
              HOW TO PLAY
            </h2>

            <div className="relative h-20 bg-gray-900/60 rounded-xl mb-6 overflow-hidden border border-white/10">
              <motion.div
                className="absolute top-1/2 -translate-y-1/2 w-8 h-5 rounded bg-cyan-400"
                animate={{ x: [10, 120, 120] }}
                transition={{ duration: 3, repeat: Infinity, repeatType: 'loop', times: [0, 0.6, 1] }}
              />
              <motion.div
                className="absolute top-1/2 -translate-y-1/2 right-0 w-8 h-5 rounded bg-pink-500"
                animate={{ x: [-10, -120, -120] }}
                transition={{ duration: 3, repeat: Infinity, repeatType: 'loop', times: [0, 0.6, 1] }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xs text-white/40">ROAD</span>
              </div>
            </div>

            <div className="space-y-4 text-left mb-8">
              {[
                { step: '1', text: 'Two cars race toward each other at full speed' },
                { step: '2', text: 'Press SPACE or TAP the screen to BRAKE' },
                { step: '3', text: 'Brake as LATE as possible \u2014 but don\'t crash!' },
                { step: '4', text: 'The most daring driver wins!' },
              ].map((item) => (
                <div key={item.step} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-8 h-8 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-sm">
                    {item.step}
                  </span>
                  <p className="text-white/80 text-sm pt-1">{item.text}</p>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-center gap-4 mb-6 text-white/50 text-xs">
              <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-lg">
                <kbd className="px-2 py-0.5 bg-white/20 rounded text-white font-mono text-xs">SPACE</kbd>
                <span>Keyboard</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-lg">
                <span>{"\u{1F446}"}</span>
                <span>Tap / Click</span>
              </div>
            </div>

            <button
              onClick={dismiss}
              className="w-full py-3 rounded-xl font-bold text-lg text-black transition-all hover:scale-105 active:scale-95"
              style={{ background: 'linear-gradient(90deg, #00e5ff, #39ff14)' }}
            >
              GOT IT! LET&apos;S RACE
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
