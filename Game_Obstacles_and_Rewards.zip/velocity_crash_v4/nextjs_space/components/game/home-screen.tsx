'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GameSettings, GameStats, MapId, Difficulty, ArenaSpeed, BotStyle, PLAYER_COLORS, LOCKED_MAP_COSTS, LOCKED_COLOR_COSTS, FREE_COLORS } from '@/lib/game-types';
import { MAPS } from '@/lib/game-constants';
import { Trophy, Zap, Timer, Palette, Map, Bot, Gauge, Volume2, VolumeX, Lock, Coins } from 'lucide-react';
import { useAudio } from '@/hooks/use-audio';
import { getCoins, isMapUnlocked, isColorUnlocked, unlockMap, unlockColor, getUnlockedMaps, getUnlockedColors } from '@/lib/coin-system';

interface HomeScreenProps {
  onStart: (settings: GameSettings) => void;
}

const STATS_KEY = 'velocity_crash_stats';

function getDefaultSettings(): GameSettings {
  return {
    difficulty: 'medium',
    arenaSpeed: 'normal',
    map: 'tokyo-night',
    botStyle: 'tactical',
    playerColor: '#00e5ff'
  };
}

function loadStats(): GameStats {
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {

    // ignore
  }return { wins: 0, losses: 0, draws: 0, bestBrakeTime: null, closestDistance: null, gamesPlayed: 0 };
}

export default function HomeScreen({ onStart }: HomeScreenProps) {
  const [settings, setSettings] = useState<GameSettings>(getDefaultSettings);
  const [stats, setStats] = useState<GameStats>({ wins: 0, losses: 0, draws: 0, bestBrakeTime: null, closestDistance: null, gamesPlayed: 0 });
  const [coins, setCoinsState] = useState(0);
  const [unlockedMaps, setUnlockedMaps] = useState<MapId[]>([]);
  const [unlockedColors, setUnlockedColorsState] = useState<string[]>([]);
  const [unlockDialog, setUnlockDialog] = useState<{type: 'map' | 'color';id: string;name: string;cost: number;} | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const { isMuted, toggleMute, musicVolume, setMusicVolume } = useAudio();

  useEffect(() => {
    setStats(loadStats());
    setCoinsState(getCoins());
    setUnlockedMaps(getUnlockedMaps() as MapId[]);
    setUnlockedColorsState(getUnlockedColors());
  }, []);

  const selectedMap = MAPS.find((m) => m.id === settings.map) ?? MAPS[0];

  const updateSetting = <K extends keyof GameSettings,>(key: K, value: GameSettings[K]) => {
    setSettings((prev) => ({ ...(prev ?? {}), [key]: value }));
  };

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handleMapClick = (mapId: MapId) => {
    if (unlockedMaps.includes(mapId)) {
      updateSetting('map', mapId);
      return;
    }
    const cost = LOCKED_MAP_COSTS[mapId];
    if (!cost) {
      updateSetting('map', mapId);
      return;
    }
    if (coins >= cost) {
      const mapName = MAPS.find((m) => m.id === mapId)?.name ?? mapId;
      setUnlockDialog({ type: 'map', id: mapId, name: mapName, cost });
    } else {
      const deficit = cost - coins;
      showToast(`Need ${deficit} more coins!`);
    }
  };

  const handleColorClick = (color: string) => {
    if (unlockedColors.includes(color)) {
      updateSetting('playerColor', color);
      return;
    }
    const cost = LOCKED_COLOR_COSTS[color];
    if (!cost) {
      updateSetting('playerColor', color);
      return;
    }
    if (coins >= cost) {
      setUnlockDialog({ type: 'color', id: color, name: color, cost });
    } else {
      const deficit = cost - coins;
      showToast(`Need ${deficit} more coins!`);
    }
  };

  const handleUnlockConfirm = () => {
    if (!unlockDialog) return;
    if (unlockDialog.type === 'map') {
      const ok = unlockMap(unlockDialog.id as MapId);
      if (ok) {
        setCoinsState(getCoins());
        setUnlockedMaps(getUnlockedMaps() as MapId[]);
        updateSetting('map', unlockDialog.id as MapId);
        showToast(`${unlockDialog.name} unlocked!`);
      }
    } else {
      const ok = unlockColor(unlockDialog.id);
      if (ok) {
        setCoinsState(getCoins());
        setUnlockedColorsState(getUnlockedColors());
        updateSetting('playerColor', unlockDialog.id);
        showToast('Color unlocked!');
      }
    }
    setUnlockDialog(null);
  };

  return (
    <div className="min-h-screen w-full overflow-y-auto" style={{ background: 'linear-gradient(180deg, #020815 0%, #0a1530 50%, #050b18 100%)' }}>
      {/* Audio Controls */}
      <div className="fixed top-4 right-4 z-50 flex items-center gap-2">
        <div className="flex items-center gap-2 bg-black/60 backdrop-blur-sm rounded-xl px-3 py-2 border border-white/10">
          <button
            onClick={toggleMute}
            className="p-1 rounded-lg hover:bg-white/10 transition-colors text-white/70 hover:text-white"
            title={isMuted ? 'Unmute' : 'Mute'}>
            
            {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={musicVolume}
            onChange={(e) => setMusicVolume(parseFloat(e.target.value))}
            className="w-20 h-1.5 cursor-pointer"
            style={{ accentColor: selectedMap?.accentColor ?? '#00e5ff' }}
            title="Music Volume" />
          
        </div>
      </div>

      {/* Toast */}
      <AnimatePresence>
        {toastMsg &&
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="fixed top-16 left-1/2 -translate-x-1/2 z-[60] px-6 py-2 rounded-xl bg-yellow-500/90 text-black font-bold text-sm shadow-lg">
          
            {toastMsg}
          </motion.div>
        }
      </AnimatePresence>

      {/* Unlock Dialog */}
      <AnimatePresence>
        {unlockDialog &&
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[70] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          
            <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            className="max-w-sm w-full rounded-2xl p-6 text-center border border-yellow-500/30"
            style={{ background: 'linear-gradient(135deg, #0a0a1a 0%, #111133 100%)' }}>
            
              <Lock size={32} className="mx-auto mb-3 text-yellow-400" />
              <h3 className="text-xl font-bold text-white mb-2">Unlock {unlockDialog.type === 'map' ? unlockDialog.name : 'this color'}?</h3>
              {unlockDialog.type === 'color' &&
            <div className="w-10 h-10 rounded-lg mx-auto mb-3 border-2 border-white/30" style={{ background: unlockDialog.id }} />
            }
              <p className="text-yellow-400 text-lg font-bold mb-4 flex items-center justify-center gap-2">
                <Coins size={20} /> {unlockDialog.cost} coins
              </p>
              <p className="text-white/50 text-sm mb-6">Your balance: {coins} coins</p>
              <div className="flex gap-3">
                <button
                onClick={handleUnlockConfirm}
                className="flex-1 py-2.5 rounded-xl font-bold text-black bg-yellow-400 hover:bg-yellow-300 transition-colors">
                
                  Unlock
                </button>
                <button
                onClick={() => setUnlockDialog(null)}
                className="flex-1 py-2.5 rounded-xl font-bold text-white bg-white/10 hover:bg-white/20 transition-colors border border-white/20">
                
                  Cancel
                </button>
              </div>
            </motion.div>
          </motion.div>
        }
      </AnimatePresence>

      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Title */}
        <motion.div
          initial={{ y: -30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-center mb-4">
          
          <h1
            className="text-5xl md:text-7xl font-bold tracking-tight font-display mb-2"
            style={{ color: '#00e5ff', textShadow: '0 0 40px rgba(0,229,255,0.4)' }}>
            
            VELOCITY CRASH
          </h1>
          <p className="text-white/50 text-sm">Brake late. Don&apos;t crash. Win.</p>
        </motion.div>

        {/* Coin Balance */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="text-center mb-6">
          
          <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-yellow-400/10 border border-yellow-400/30">
            <Coins size={22} className="text-yellow-400" />
            <span className="text-2xl font-bold font-mono text-yellow-400">
              {coins.toLocaleString()}
            </span>
          </div>
        </motion.div>

        {/* Map Selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="mb-8">
          
          <h2 className="text-white/70 text-sm font-bold uppercase mb-3 flex items-center gap-2">
            <Map size={16} /> SELECT MAP
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {MAPS.map((map, i) => {
              const locked = !unlockedMaps.includes(map.id);
              const cost = LOCKED_MAP_COSTS[map.id];
              return (
                <motion.button
                  key={map.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.1 + i * 0.05 }}
                  onClick={() => handleMapClick(map.id)}
                  className="relative rounded-xl p-4 text-left transition-all border-2 overflow-hidden group"
                  style={{
                    background: locked ?
                    'linear-gradient(135deg, #222, #333)' :
                    `linear-gradient(135deg, ${map.bgColor}, ${map.bgColor}ee)`,
                    borderColor: settings.map === map.id && !locked ? map.accentColor : 'rgba(255,255,255,0.1)',
                    boxShadow: settings.map === map.id && !locked ? `0 0 20px ${map.accentColor}44` : 'none'
                  }}>
                  
                  {locked &&
                  <div className="absolute inset-0 flex items-center justify-center z-10">
                      <div className="flex flex-col items-center gap-1">
                        <Lock size={24} className="text-white/60" />
                        {cost &&
                      <span className="text-xs font-bold text-yellow-400 flex items-center gap-1">
                            <Coins size={12} /> {cost}
                          </span>
                      }
                      </div>
                    </div>
                  }
                  <div className={locked ? 'opacity-40 grayscale' : ''}>
                    <div className="text-2xl mb-1">{map.emoji}</div>
                    <div className="text-sm font-bold text-white">{map.name}</div>
                    <div className="text-xs text-white/40 mt-0.5">{map.description}</div>
                  </div>
                  <div
                    className="absolute top-2 right-2 w-3 h-3 rounded-full"
                    style={{ background: locked ? '#555' : map.accentColor, opacity: settings.map === map.id && !locked ? 1 : 0.3 }} />
                  
                </motion.button>);

            })}
          </div>
        </motion.div>

        {/* Settings Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          
          {/* Difficulty */}
          <SettingCard icon={<Zap size={16} />} title="DIFFICULTY">
            <div className="flex flex-wrap gap-2">
              {(['easy', 'medium', 'hard', 'impossible'] as Difficulty[]).map((d) =>
              <OptionBtn
                key={d}
                label={d.toUpperCase()}
                active={settings.difficulty === d}
                onClick={() => updateSetting('difficulty', d)}
                color={selectedMap.accentColor} />

              )}
            </div>
            {(settings.difficulty === 'hard' || settings.difficulty === 'impossible') &&
            <p className="text-xs text-yellow-400/70 mt-2">Obstacles active on this difficulty</p>
            }
          </SettingCard>

          {/* Arena Speed */}
          <SettingCard icon={<Gauge size={16} />} title="ARENA SPEED">
            <div className="flex flex-wrap gap-2">
              {(['slow', 'normal', 'fast', 'turbo'] as ArenaSpeed[]).map((s) =>
              <OptionBtn
                key={s}
                label={s.toUpperCase()}
                active={settings.arenaSpeed === s}
                onClick={() => updateSetting('arenaSpeed', s)}
                color={selectedMap.accentColor} />

              )}
            </div>
          </SettingCard>

          {/* Bot Style */}
          <SettingCard icon={<Bot size={16} />} title="BOT STYLE">
            <div className="flex flex-wrap gap-2">
              {(['aggressive', 'tactical', 'unpredictable'] as BotStyle[]).map((b) =>
              <OptionBtn
                key={b}
                label={b.toUpperCase()}
                active={settings.botStyle === b}
                onClick={() => updateSetting('botStyle', b)}
                color={selectedMap.accentColor} />

              )}
            </div>
          </SettingCard>

          {/* Player Color */}
          <SettingCard icon={<Palette size={16} />} title="PLAYER COLOR">
            <div className="flex flex-wrap gap-2">
              {PLAYER_COLORS.map((c) => {
                const locked = !unlockedColors.includes(c);
                const cost = LOCKED_COLOR_COSTS[c];
                return (
                  <div key={c} className="relative">
                    <button
                      onClick={() => handleColorClick(c)}
                      className="w-9 h-9 rounded-lg border-2 transition-all hover:scale-110"
                      style={{
                        background: locked ? '#555' : c,
                        borderColor: settings.playerColor === c && !locked ? '#fff' : 'rgba(255,255,255,0.15)',
                        boxShadow: settings.playerColor === c && !locked ? `0 0 12px ${c}88` : 'none'
                      }}>
                      
                      {locked &&
                      <Lock size={12} className="text-white/80 mx-auto" />
                      }
                    </button>
                    {locked && cost &&
                    <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[9px] font-bold text-yellow-400 whitespace-nowrap">
                        {cost}
                      </span>
                    }
                  </div>);

              })}
            </div>
          </SettingCard>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="rounded-xl p-4 mb-8 border border-white/10"
          style={{ background: 'rgba(255,255,255,0.03)' }}>
          
          <h3 className="text-white/50 text-xs font-bold uppercase mb-3 flex items-center gap-2">
            <Trophy size={14} /> YOUR STATS
          </h3>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-3 text-center">
            <StatItem label="Wins" value={String(stats?.wins ?? 0)} color="#39ff14" />
            <StatItem label="Losses" value={String(stats?.losses ?? 0)} color="#ff3333" />
            <StatItem label="Draws" value={String(stats?.draws ?? 0)} color="#ffdd00" />
            <StatItem label="Best Brake" value={stats?.bestBrakeTime != null ? `${(stats.bestBrakeTime * 1000).toFixed(0)}ms` : '\u2014'} color="#00e5ff" />
            <StatItem label="Games" value={String(stats?.gamesPlayed ?? 0)} color="#a78bfa" />
            <StatItem label="Coins" value={String(coins)} color="#ffcc00" />
          </div>
        </motion.div>

        {/* Start Button */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center">
          
          <button
            onClick={() => onStart?.(settings)}
            className="px-12 py-4 rounded-2xl text-xl font-bold text-black transition-all hover:scale-105 active:scale-95"
            style={{
              background: `linear-gradient(90deg, ${selectedMap.accentColor}, ${selectedMap.secondaryColor})`,
              boxShadow: `0 0 30px ${selectedMap.accentColor}44`
            }}>
            
            START RACE
          </button>
          <p className="text-white/30 text-xs mt-3">Press SPACE to brake during the race</p>
        </motion.div>
      </div>
    </div>);

}

function SettingCard({ icon, title, children }: {icon: React.ReactNode;title: string;children: React.ReactNode;}) {
  return (
    <div className="rounded-xl p-4 border border-white/10" style={{ background: '#0c0e1e' }}>
      <h3 className="text-white/50 text-xs font-bold uppercase mb-3 flex items-center gap-2">
        {icon} {title}
      </h3>
      {children}
    </div>);

}

function OptionBtn({ label, active, onClick, color }: {label: string;active: boolean;onClick: () => void;color: string;}) {
  return (
    <button
      onClick={onClick}
      className="px-3 py-1.5 rounded-lg text-xs font-bold transition-all"
      style={{
        background: active ? 'rgba(20,20,40,0.95)' : 'rgba(20,20,40,0.7)',
        color: active ? '#ffffff' : 'rgba(255,255,255,0.5)',
        border: `1px solid ${active ? color : 'rgba(255,255,255,0.1)'}`,
        textShadow: active ? `0 0 8px ${color}` : 'none',
        boxShadow: active ? `0 0 10px ${color}33` : 'none'
      }}>
      
      {label}
    </button>);

}

function StatItem({ label, value, color }: {label: string;value: string;color: string;}) {
  return (
    <div>
      <div className="text-lg font-bold font-mono" style={{ color }}>{value}</div>
      <div className="text-xs text-white/40">{label}</div>
    </div>);

}