'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const OBSTACLE_TUTORIAL_KEY = 'velocity_crash_obstacle_tutorial_seen';

interface ObstacleInfo {
  emoji: string;
  name: string;
  description: string;
  color: string;
}

const OBSTACLES: ObstacleInfo[] = [
{
  emoji: '\u{1F6A7}',
  name: 'BARRIER',
  description: 'A wall of pain. Slams your brakes into molasses mode. Hit it and you\'ll be stopping like a shopping cart with a wonky wheel.',
  color: '#ff4400'
},
{
  emoji: '\u{1F4A7}',
  name: 'OIL SLICK',
  description: 'Rainbow death juice on the road. Your brakes? Gone. Reduced to atoms. Good luck stopping, chief.',
  color: '#aa44ff'
},
{
  emoji: '\u26A1',
  name: 'SPEED BURST',
  description: 'Lightning-flavored adrenaline. You\'ll go FAST. Dangerously fast. "I regret everything" fast.',
  color: '#ffdd00'
},
{
  emoji: '\u{1F680}',
  name: 'BOOST FIELD',
  description: 'A glowing green zone of MAXIMUM OVERDRIVE. Your acceleration doubles. The gap closes. Your palms sweat. This is fine.',
  color: '#39ff14'
},
{
  emoji: '\u2744\uFE0F',
  name: 'SLOW FIELD',
  description: 'Icy trap of deception. "Oh I\'m going slow, easy brake!" WRONG. Your brakes are frozen too. Surprise!',
  color: '#66ccff'
},
{
  emoji: '\u{1F34C}',
  name: 'BANANA PEEL',
  description: 'Classic chaos. Your car starts wiggling like it\'s having an existential crisis. Speed goes brrr-bzzt-brrr while your brakes weep.',
  color: '#ffcc00'
},
{
  emoji: '\u{1F986}',
  name: 'RUBBER DUCKY',
  description: 'QUACK! A bouncy bath toy of doom. Your car goes boing, speed drops, brakes get rubbery. It\'s adorable. It\'s lethal.',
  color: '#ffaa00'
},
{
  emoji: '\u{1F4F8}',
  name: 'SPEED CAMERA',
  description: 'BUSTED! Caught going too fast. Speed instantly halved like a traffic fine from hell. The flash is blinding. The shame is worse.',
  color: '#888888'
},
{
  emoji: '\u{1F300}',
  name: 'WORMHOLE',
  description: 'A swirling portal that TELEPORTS you forward. Could save you. Could kill you. Probably kill you. Definitely kill you.',
  color: '#c084fc'
}];


interface ObstacleTutorialModalProps {
  show: boolean;
  onDismiss: () => void;
}

export default function ObstacleTutorialModal({ show, onDismiss }: ObstacleTutorialModalProps) {
  const handleDismiss = () => {
    try {
      localStorage?.setItem?.(OBSTACLE_TUTORIAL_KEY, 'true');
    } catch {/* ignore */}
    onDismiss?.();
  };

  return (
    <AnimatePresence>
      {show &&
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[110] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4">
        
          <motion.div
          initial={{ scale: 0.8, y: 50, opacity: 0 }}
          animate={{ scale: 1, y: 0, opacity: 1 }}
          exit={{ scale: 0.8, y: 50, opacity: 0 }}
          transition={{ type: 'spring', damping: 18 }}
          className="max-w-2xl w-full max-h-[90vh] overflow-y-auto rounded-2xl border border-red-500/30 p-6"
          style={{ background: 'linear-gradient(135deg, #0d0000 0%, #1a0510 50%, #0a0a1a 100%)' }}>
          
            <div className="text-center mb-6">
              <h2 className="text-3xl md:text-4xl font-bold text-red-400 tracking-tight font-display mb-2">
                OBSTACLE WARNING 
              </h2>
              <p className="text-white/50 text-sm">CLASSIFIED BRIEFING/ Eyes Only</p>
              <p className="text-yellow-400/60 text-xs mt-1">The road ahead is... complicated.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">
              {OBSTACLES.map((obs, i) =>
            <motion.div
              key={obs.name}
              initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 + i * 0.06 }}
              className="rounded-xl p-3 border"
              style={{
                background: obs.color + '10',
                borderColor: obs.color + '33'
              }}>
              
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xl">{obs.emoji}</span>
                    <span className="text-sm font-bold" style={{ color: obs.color }}>{obs.name}</span>
                  </div>
                  <p className="text-xs text-white/60 leading-relaxed">{obs.description}</p>
                </motion.div>
            )}
            </div>

            <div className="text-center">
              <button
              onClick={handleDismiss}
              className="px-8 py-3 rounded-xl font-bold text-lg text-black transition-all hover:scale-105 active:scale-95"
              style={{ background: 'linear-gradient(90deg, #ff3300, #ff8c00)' }}>
              
                I'M READY/ RACE!
              </button>
            </div>
          </motion.div>
        </motion.div>
      }
    </AnimatePresence>);

}

export function hasSeenObstacleTutorial(): boolean {
  try {
    return localStorage?.getItem?.(OBSTACLE_TUTORIAL_KEY) === 'true';
  } catch {
    return true;
  }
}