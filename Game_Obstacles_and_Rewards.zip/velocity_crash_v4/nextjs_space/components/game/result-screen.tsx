'use client';

import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { GameState, Difficulty } from '@/lib/game-types';
import { useAudio } from '@/hooks/use-audio';
import { calculateCoinsEarned, addCoins, getCoins } from '@/lib/coin-system';
import { ARENA_WIDTH } from '@/lib/game-constants';
import { Coins } from 'lucide-react';

interface ResultScreenProps {
  gameState: GameState;
  difficulty: Difficulty;
  onPlayAgain: () => void;
  onChangeSettings: () => void;
  accentColor: string;
}

export default function ResultScreen({ gameState, difficulty, onPlayAgain, onChangeSettings, accentColor }: ResultScreenProps) {
  const isWin = gameState?.winner === 'player';
  const isDraw = gameState?.winner === 'draw';
  const isCrash = gameState?.resultType === 'crash';
  const { playSound } = useAudio();
  const sfxPlayedRef = useRef(false);
  const coinsAddedRef = useRef(false);

  const [displayedCoins, setDisplayedCoins] = useState(0);
  const [totalBalance, setTotalBalance] = useState(0);
  const earned = calculateCoinsEarned(gameState, difficulty);

  useEffect(() => {
    if (!sfxPlayedRef.current) {
      sfxPlayedRef.current = true;
    }
  }, []);

  // Add coins on mount
  useEffect(() => {
    if (!coinsAddedRef.current && earned > 0) {
      coinsAddedRef.current = true;
      const newBalance = addCoins(earned);
      setTotalBalance(newBalance);
    } else if (!coinsAddedRef.current) {
      coinsAddedRef.current = true;
      setTotalBalance(getCoins());
    }
  }, [earned]);

  // Animated counter
  useEffect(() => {
    if (earned <= 0) {
      setDisplayedCoins(0);
      return;
    }
    let frame = 0;
    const totalFrames = 40;
    const interval = setInterval(() => {
      frame++;
      const progress = Math.min(1, frame / totalFrames);
      setDisplayedCoins(Math.round(earned * progress));
      if (frame >= totalFrames) clearInterval(interval);
    }, 30);
    return () => clearInterval(interval);
  }, [earned]);

  const title = isDraw ? 'DRAW!' : isWin ? 'VICTORY!' : 'DEFEAT!';
  const titleColor = isDraw ? '#ffdd00' : isWin ? '#ffd700' : '#ff3333';
  const subtitle = isCrash
    ? isWin
      ? 'You survived the crash!'
      : 'You crashed too hard!'
    : isWin
    ? 'You braked later and lived!'
    : isDraw
    ? 'A perfectly matched race!'
    : 'The bot was more daring!';

  const playerBrakeMs = ((gameState?.playerBrakeTime ?? 0) * 1000).toFixed(0);
  const botBrakeMs = ((gameState?.botBrakeTime ?? 0) * 1000).toFixed(0);
  const gap = Math.max(0, (gameState?.botPos ?? ARENA_WIDTH) - (gameState?.playerPos ?? 0));
  const closedPct = Math.min(100, ((ARENA_WIDTH - gap) / ARENA_WIDTH) * 100).toFixed(1);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', damping: 15, delay: 0.2 }}
        className="max-w-md w-full rounded-2xl p-8 text-center border"
        style={{
          background: 'linear-gradient(135deg, #0a0a1a 0%, #111133 100%)',
          borderColor: titleColor + '44',
        }}
      >
        <motion.h1
          initial={{ scale: 2, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', damping: 10, delay: 0.4 }}
          className="text-5xl font-bold mb-2 tracking-tight font-display"
          style={{ color: titleColor, textShadow: `0 0 30px ${titleColor}88` }}
        >
          {title}
        </motion.h1>

        <p className="text-white/60 text-sm mb-3">{subtitle}</p>

        {/* Coins earned */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mb-4"
        >
          {earned > 0 ? (
            <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-yellow-400/15 border border-yellow-400/30">
              <Coins size={20} className="text-yellow-400" />
              <span className="text-2xl font-bold font-mono text-yellow-400">+{displayedCoins}</span>
            </div>
          ) : (
            <p className="text-white/30 text-sm">No coins earned</p>
          )}
          <p className="text-white/40 text-xs mt-1">Balance: {totalBalance.toLocaleString()} coins</p>
        </motion.div>

        {isCrash && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mb-4 px-3 py-2 rounded-lg bg-red-900/30 border border-red-500/30"
          >
            <span className="text-red-400 text-sm font-bold">{"\u{1F4A5}"} COLLISION</span>
          </motion.div>
        )}

        <div className="grid grid-cols-2 gap-4 mb-6">
          {[
            { label: 'Your Brake', value: `${playerBrakeMs}ms`, highlight: isWin },
            { label: 'Bot Brake', value: `${botBrakeMs}ms`, highlight: !isWin && !isDraw },
            { label: 'Distance Closed', value: `${closedPct}%`, highlight: false },
            { label: 'Final Gap', value: `${Math.round(gap)}u`, highlight: false },
          ].map((item, i) => (
            <motion.div
              key={item.label}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.6 + i * 0.1 }}
              className="rounded-xl p-3 border"
              style={{
                background: item.highlight ? accentColor + '15' : 'rgba(255,255,255,0.05)',
                borderColor: item.highlight ? accentColor + '44' : 'rgba(255,255,255,0.1)',
              }}
            >
              <div className="text-xs text-white/50 mb-1">{item.label}</div>
              <div className="text-lg font-bold text-white font-mono">{item.value}</div>
            </motion.div>
          ))}
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => onPlayAgain?.()}
            className="flex-1 py-3 rounded-xl font-bold text-black transition-all hover:scale-105 active:scale-95"
            style={{ background: `linear-gradient(90deg, ${accentColor}, ${accentColor}cc)` }}
          >
            PLAY AGAIN
          </button>
          <button
            onClick={() => onChangeSettings?.()}
            className="flex-1 py-3 rounded-xl font-bold text-white transition-all hover:scale-105 active:scale-95 bg-white/10 hover:bg-white/20 border border-white/20"
          >
            SETTINGS
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
