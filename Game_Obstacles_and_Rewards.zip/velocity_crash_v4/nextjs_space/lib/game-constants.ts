import { MapConfig, MapId, Difficulty, ArenaSpeed } from './game-types';

export const ARENA_WIDTH = 1000;
export const CAR_WIDTH = 40;
export const BASE_ACCELERATION = 400;
export const BASE_MAX_VELOCITY = 600;
export const BRAKE_DECELERATION = 1200;
export const SAFE_SPEED = 30;

export const SPEED_MULTIPLIERS: Record<ArenaSpeed, number> = {
  slow: 0.6,
  normal: 1.0,
  fast: 1.5,
  turbo: 2.0,
};

export const BOT_DELAY: Record<Difficulty, number> = {
  easy: 800,
  medium: 400,
  hard: 120,
  impossible: 0,
};

export const MAPS: MapConfig[] = [
  {
    id: 'tokyo-night',
    name: 'TOKYO NIGHT',
    emoji: '\u{1F303}',
    bgColor: '#050b18',
    accentColor: '#00e5ff',
    secondaryColor: '#ff00ff',
    roadColor: '#1a1a2e',
    description: 'Neon-lit streets with rain',
  },
  {
    id: 'sakura-pass',
    name: 'SAKURA PASS',
    emoji: '\u{1F338}',
    bgColor: '#1a0a1e',
    accentColor: '#ff69b4',
    secondaryColor: '#c084fc',
    roadColor: '#2a1a2e',
    description: 'Mountain pass with cherry blossoms',
  },
  {
    id: 'neon-circuit',
    name: 'NEON CIRCUIT',
    emoji: '\u26A1',
    bgColor: '#000510',
    accentColor: '#39ff14',
    secondaryColor: '#ff00ff',
    roadColor: '#0a0a1a',
    description: 'Electric grid with lightning',
  },
  {
    id: 'ocean-drive',
    name: 'OCEAN DRIVE',
    emoji: '\u{1F30A}',
    bgColor: '#0a1628',
    accentColor: '#00bfff',
    secondaryColor: '#ff6b35',
    roadColor: '#1a2638',
    description: 'Coastal highway at sunset',
  },
  {
    id: 'space-drift',
    name: 'SPACE DRIFT',
    emoji: '\u{1F680}',
    bgColor: '#020010',
    accentColor: '#a78bfa',
    secondaryColor: '#ec4899',
    roadColor: '#0a0520',
    description: 'Deep space with nebulae',
  },
  {
    id: 'crimson-dojo',
    name: 'CRIMSON DOJO',
    emoji: '\u{1F525}',
    bgColor: '#0d0000',
    accentColor: '#ff3300',
    secondaryColor: '#ff8c00',
    roadColor: '#1a0a0a',
    description: 'Fiery dojo with sparks',
  },
];

export function getMapConfig(id: MapId): MapConfig {
  return MAPS.find((m) => m.id === id) ?? MAPS[0];
}
