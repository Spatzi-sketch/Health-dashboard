import { GameState, Difficulty, MapId, DIFFICULTY_COIN_MULTIPLIER, FREE_MAPS, LOCKED_MAP_COSTS, FREE_COLORS, LOCKED_COLOR_COSTS } from './game-types';
import { ARENA_WIDTH } from './game-constants';

const COINS_KEY = 'velocity_crash_coins';
const UNLOCKED_MAPS_KEY = 'velocity_crash_unlocked_maps';
const UNLOCKED_COLORS_KEY = 'velocity_crash_unlocked_colors';

export function getCoins(): number {
  try {
    const raw = localStorage?.getItem?.(COINS_KEY);
    if (raw != null) return parseInt(raw, 10) || 0;
  } catch { /* ignore */ }
  return 0;
}

export function setCoins(amount: number): void {
  try {
    localStorage?.setItem?.(COINS_KEY, String(Math.max(0, amount)));
  } catch { /* ignore */ }
}

export function addCoins(amount: number): number {
  const current = getCoins();
  const newAmount = current + amount;
  setCoins(newAmount);
  return newAmount;
}

export function deductCoins(amount: number): boolean {
  const current = getCoins();
  if (current < amount) return false;
  setCoins(current - amount);
  return true;
}

/**
 * Calculate coins earned for a completed game.
 * Returns 0 if player lost.
 */
export function calculateCoinsEarned(state: GameState, difficulty: Difficulty): number {
  if (state?.winner !== 'player' && state?.winner !== 'draw') return 0;

  const diffMult = DIFFICULTY_COIN_MULTIPLIER[difficulty] ?? 0.2;
  const finalGap = Math.max(0, (state?.botPos ?? ARENA_WIDTH) - (state?.playerPos ?? 0));
  const distanceClosed = ARENA_WIDTH - finalGap;
  const precisionScore = Math.max(0, Math.min(1, distanceClosed / ARENA_WIDTH));

  return Math.min(100, Math.max(0, Math.round(100 * diffMult * precisionScore)));
}

// --- Unlocked Maps ---
export function getUnlockedMaps(): MapId[] {
  try {
    const raw = localStorage?.getItem?.(UNLOCKED_MAPS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as string[];
      // Always include free maps
      const set = new Set([...FREE_MAPS, ...parsed]);
      return Array.from(set) as MapId[];
    }
  } catch { /* ignore */ }
  return [...FREE_MAPS];
}

export function unlockMap(mapId: MapId): boolean {
  const cost = LOCKED_MAP_COSTS[mapId];
  if (!cost) return true; // Free map
  if (!deductCoins(cost)) return false;
  const current = getUnlockedMaps();
  if (!current.includes(mapId)) {
    current.push(mapId);
    try {
      localStorage?.setItem?.(UNLOCKED_MAPS_KEY, JSON.stringify(current));
    } catch { /* ignore */ }
  }
  return true;
}

export function isMapUnlocked(mapId: MapId): boolean {
  return getUnlockedMaps().includes(mapId);
}

// --- Unlocked Colors ---
export function getUnlockedColors(): string[] {
  try {
    const raw = localStorage?.getItem?.(UNLOCKED_COLORS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as string[];
      const set = new Set([...FREE_COLORS, ...parsed]);
      return Array.from(set);
    }
  } catch { /* ignore */ }
  return [...FREE_COLORS];
}

export function unlockColor(color: string): boolean {
  const cost = LOCKED_COLOR_COSTS[color];
  if (!cost) return true; // Free color
  if (!deductCoins(cost)) return false;
  const current = getUnlockedColors();
  if (!current.includes(color)) {
    current.push(color);
    try {
      localStorage?.setItem?.(UNLOCKED_COLORS_KEY, JSON.stringify(current));
    } catch { /* ignore */ }
  }
  return true;
}

export function isColorUnlocked(color: string): boolean {
  return getUnlockedColors().includes(color);
}
