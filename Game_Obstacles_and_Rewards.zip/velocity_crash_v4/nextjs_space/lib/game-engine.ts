import {
  GameState, GameSettings, ObstacleEffect, Difficulty, BotStyle,
} from './game-types';
import {
  ARENA_WIDTH, CAR_WIDTH, BASE_ACCELERATION, BASE_MAX_VELOCITY,
  BRAKE_DECELERATION, SAFE_SPEED, SPEED_MULTIPLIERS, BOT_DELAY,
} from './game-constants';
import {
  getBrakeMultiplier, getAccelMultiplier, checkObstacleCollision,
  updateObstacles, updateEffects, generateObstacles, shouldHaveObstacles,
} from './obstacle-system';

export function createInitialState(settings: GameSettings, canvasH: number): GameState {
  return {
    phase: 'countdown',
    countdownValue: 3,
    playerPos: 0,
    playerVel: 0,
    playerBraking: false,
    botPos: ARENA_WIDTH,
    botVel: 0,
    botBraking: false,
    winner: null,
    resultType: null,
    playerBrakeTime: 0,
    botBrakeTime: 0,
    raceStartTime: 0,
    elapsed: 0,
    playerEffects: [],
    botEffects: [],
    obstacles: shouldHaveObstacles(settings.difficulty)
      ? generateObstacles(settings.difficulty, canvasH)
      : [],
    impactText: null,
    impactTextTimer: 0,
    shakeIntensity: 0,
    playerJitter: false,
    botJitter: false,
    playerBounce: false,
    botBounce: false,
  };
}

/** Track impossible bot per-instance state */
let impossibleBotDelayedFrame = false;

export function updateGameState(
  state: GameState,
  dt: number,
  settings: GameSettings,
  playerBrakeInput: boolean,
  canvasH: number
): GameState {
  if (state.phase !== 'racing') return state;

  const speedMult = SPEED_MULTIPLIERS[settings.arenaSpeed] ?? 1;
  const accel = BASE_ACCELERATION * speedMult;
  const maxVel = BASE_MAX_VELOCITY * speedMult;
  const brakePower = BRAKE_DECELERATION * speedMult;
  const elapsed = state.elapsed + dt;

  let playerVel = state.playerVel;
  let playerPos = state.playerPos;
  let playerBraking = state.playerBraking;
  let playerBrakeTime = state.playerBrakeTime;
  let playerEffects = updateEffects([...(state.playerEffects ?? [])], dt);

  let botVel = state.botVel;
  let botPos = state.botPos;
  let botBraking = state.botBraking;
  let botBrakeTime = state.botBrakeTime;
  let botEffects = updateEffects([...(state.botEffects ?? [])], dt);

  let obstacles = updateObstacles([...(state.obstacles ?? [])], dt, canvasH);
  let impactText = state.impactText;
  let impactTextTimer = Math.max(0, (state.impactTextTimer ?? 0) - dt);
  let shakeIntensity = Math.max(0, (state.shakeIntensity ?? 0) - dt * 10);
  let playerJitter = false;
  let botJitter = false;
  let playerBounce = false;
  let botBounce = false;

  if (impactTextTimer <= 0) impactText = null;

  // Player brake input
  if (playerBrakeInput && !playerBraking) {
    playerBraking = true;
    playerBrakeTime = elapsed;
    impactText = 'BRAKE!';
    impactTextTimer = 0.8;
  }

  // --- Handle special obstacle effects on player ---
  // Banana jitter: ±20% velocity oscillation
  const hasBanana = (playerEffects ?? []).some((e: ObstacleEffect) => e.type === 'banana-peel');
  if (hasBanana) {
    playerVel = playerVel * (1 + (Math.random() - 0.5) * 0.4);
    playerJitter = true;
  }

  // Rubber ducky: speed set to 80%
  const hasDucky = (playerEffects ?? []).some((e: ObstacleEffect) => e.type === 'rubber-ducky');
  if (hasDucky) {
    playerVel = playerVel * 0.8;
    playerBounce = true;
  }

  // Speed camera: slow to 50% velocity instantly (applied on first frame only via high timeLeft)
  const speedCamEffect = (playerEffects ?? []).find((e: ObstacleEffect) => e.type === 'speed-camera' && e.timeLeft > 0.9);
  if (speedCamEffect) {
    playerVel = playerVel * 0.5;
    impactText = 'BUSTED!';
    impactTextTimer = 0.8;
    shakeIntensity = 5;
  }

  // Wormhole: teleport forward
  const wormholeEffect = (playerEffects ?? []).find((e: ObstacleEffect) => e.type === 'wormhole' && e.teleportAmount && e.timeLeft > 0.2);
  if (wormholeEffect && (wormholeEffect.teleportAmount ?? 0) > 0) {
    playerPos += wormholeEffect.teleportAmount ?? 0;
    wormholeEffect.teleportAmount = 0; // consume
    impactText = 'WARP!';
    impactTextTimer = 0.8;
  }

  // Player physics
  const pAccelMult = getAccelMultiplier(playerEffects);
  const pBrakeMult = getBrakeMultiplier(playerEffects);
  if (playerBraking) {
    playerVel = Math.max(0, playerVel - brakePower * pBrakeMult * dt);
  } else {
    playerVel = Math.min(maxVel, playerVel + accel * pAccelMult * dt);
  }
  playerPos = playerPos + playerVel * dt;

  // --- Bot AI ---
  const botAccelMult = getAccelMultiplier(botEffects);
  const botBrakeMult = getBrakeMultiplier(botEffects);

  // Handle bot banana/ducky effects
  const botHasBanana = (botEffects ?? []).some((e: ObstacleEffect) => e.type === 'banana-peel');
  if (botHasBanana) {
    botVel = botVel * (1 + (Math.random() - 0.5) * 0.4);
    botJitter = true;
  }
  const botHasDucky = (botEffects ?? []).some((e: ObstacleEffect) => e.type === 'rubber-ducky');
  if (botHasDucky) {
    botVel = botVel * 0.8;
    botBounce = true;
  }
  const botSpeedCam = (botEffects ?? []).find((e: ObstacleEffect) => e.type === 'speed-camera' && e.timeLeft > 0.9);
  if (botSpeedCam) {
    botVel = botVel * 0.5;
  }
  // Bot wormhole: teleport bot backward (closer to player)
  const botWormhole = (botEffects ?? []).find((e: ObstacleEffect) => e.type === 'wormhole' && e.teleportAmount && e.timeLeft > 0.2);
  if (botWormhole && (botWormhole.teleportAmount ?? 0) > 0) {
    botPos -= botWormhole.teleportAmount ?? 0;
    botWormhole.teleportAmount = 0;
  }

  if (!botBraking) {
    botVel = Math.min(maxVel, botVel + accel * botAccelMult * dt);
    botPos = botPos - botVel * dt;

    const gap = botPos - playerPos;
    const stoppingDist = (botVel * botVel) / (2 * brakePower * Math.max(0.1, botBrakeMult));
    const playerStoppingDist = (playerVel * playerVel) / (2 * brakePower);
    const closingSpeed = playerVel + botVel;

    if (settings.difficulty === 'impossible') {
      // IMPOSSIBLE BOT: mirror player brake + last-second safety
      let shouldBrake = false;

      // 1. If player has braked, bot brakes instantly (or with 7% delay chance)
      if (playerBraking) {
        if (impossibleBotDelayedFrame) {
          // Was delayed last frame, now brake
          shouldBrake = true;
          impossibleBotDelayedFrame = false;
        } else if (Math.random() < 0.07) {
          // 7% chance to delay 1 frame
          impossibleBotDelayedFrame = true;
          shouldBrake = false;
        } else {
          shouldBrake = true;
        }
      }

      // 2. Even if player hasn't braked, use absolute minimum safety margin
      const minSafety = stoppingDist + playerStoppingDist + CAR_WIDTH * 1.1;
      if (gap <= minSafety) {
        shouldBrake = true;
      }

      if (shouldBrake) {
        botBraking = true;
        botBrakeTime = elapsed;
      }
    } else {
      // Normal bot logic for easy/medium/hard
      const delayMs = BOT_DELAY[settings.difficulty] ?? 400;
      const riskFactor = getRiskFactor(settings.botStyle, settings.difficulty);
      const totalStoppingDist = stoppingDist + playerStoppingDist;
      let brakeThreshold = totalStoppingDist + CAR_WIDTH + (delayMs / 1000) * closingSpeed;

      // Fix: Never allow brakeThreshold to go below minimum safe distance
      const minThreshold = stoppingDist + CAR_WIDTH * 0.5;
      if (brakeThreshold < minThreshold) {
        brakeThreshold = minThreshold;
      }

      if (gap <= brakeThreshold * riskFactor) {
        botBraking = true;
        botBrakeTime = elapsed;
      }
    }
  } else {
    botVel = Math.max(0, botVel - brakePower * botBrakeMult * dt);
    botPos = botPos - botVel * dt;
  }

  // Obstacle collisions
  if ((obstacles?.length ?? 0) > 0) {
    const pResult = checkObstacleCollision(playerPos, obstacles, playerEffects);
    playerEffects = pResult.effects;
    obstacles = pResult.obstacles;

    const bResult = checkObstacleCollision(ARENA_WIDTH - botPos, obstacles, botEffects);
    botEffects = bResult.effects;
    obstacles = bResult.obstacles;
  }

  // Collision detection
  const gap = botPos - playerPos;
  let winner = state.winner;
  let resultType = state.resultType;
  let phase: GameState['phase'] = 'racing';

  if (gap <= CAR_WIDTH) {
    if (playerVel > SAFE_SPEED || botVel > SAFE_SPEED) {
      resultType = 'crash';
      impactText = 'CRASH!';
      impactTextTimer = 2;
      shakeIntensity = 15;
      if (playerVel <= SAFE_SPEED) {
        winner = 'player';
      } else if (botVel <= SAFE_SPEED) {
        winner = 'bot';
      } else {
        winner = playerVel <= botVel ? 'player' : 'bot';
      }
      phase = 'result';
    } else {
      resultType = 'safe';
      phase = 'result';
      if (Math.abs(playerBrakeTime - botBrakeTime) < 0.05) {
        winner = 'draw';
      } else {
        winner = playerBrakeTime > botBrakeTime ? 'player' : 'bot';
      }
      impactText = winner === 'player' ? 'VICTORY!' : winner === 'bot' ? 'DEFEAT!' : 'DRAW!';
      impactTextTimer = 2;
    }
  } else if (playerVel <= 0.1 && botVel <= 0.1 && playerBraking && botBraking) {
    resultType = 'safe';
    phase = 'result';
    const playerDist = playerPos;
    const botDist = ARENA_WIDTH - botPos;
    if (Math.abs(playerDist - botDist) < 5) {
      winner = 'draw';
    } else {
      winner = playerDist > botDist ? 'player' : 'bot';
    }
    impactText = winner === 'player' ? 'VICTORY!' : winner === 'bot' ? 'DEFEAT!' : 'DRAW!';
    impactTextTimer = 2;
  }

  return {
    ...state,
    phase,
    playerPos,
    playerVel,
    playerBraking,
    playerBrakeTime,
    botPos,
    botVel,
    botBraking,
    botBrakeTime,
    elapsed,
    winner,
    resultType,
    playerEffects,
    botEffects,
    obstacles,
    impactText,
    impactTextTimer,
    shakeIntensity,
    playerJitter,
    botJitter,
    playerBounce,
    botBounce,
  };
}

export function getRiskFactor(botStyle: BotStyle, difficulty: Difficulty): number {
  const base: Record<BotStyle, number> = {
    aggressive: 0.72,
    tactical: 1.1,
    unpredictable: 0.7 + Math.random() * 0.6,
  };
  const diffMod: Record<Difficulty, number> = {
    easy: 1.3,
    medium: 1.1,
    hard: 0.95,
    impossible: 0.85,
  };
  return (base[botStyle] ?? 1) * (diffMod[difficulty] ?? 1);
}
