import { Obstacle, ObstacleEffect, ObstacleType, Difficulty } from './game-types';
import { ARENA_WIDTH } from './game-constants';

export function shouldHaveObstacles(difficulty: Difficulty): boolean {
  return difficulty === 'hard' || difficulty === 'impossible';
}

const OLD_TYPES: ObstacleType[] = ['barrier', 'oil-slick', 'speed-burst'];
const NEW_TYPES: ObstacleType[] = ['boost-field', 'slow-field', 'banana-peel', 'rubber-ducky', 'speed-camera', 'wormhole'];
const ALL_TYPES: ObstacleType[] = [...OLD_TYPES, ...NEW_TYPES];

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function generateObstacles(difficulty: Difficulty, canvasH: number): Obstacle[] {
  if (!shouldHaveObstacles(difficulty)) return [];

  const count = difficulty === 'impossible'
    ? 2 + Math.floor(Math.random() * 3) // 2-4
    : 1 + Math.floor(Math.random() * 2); // 1-2

  const obstacles: Obstacle[] = [];

  for (let i = 0; i < count; i++) {
    let type: ObstacleType;
    if (difficulty === 'impossible') {
      // Heavier weighting toward new tricky obstacles
      type = Math.random() < 0.65 ? pickRandom(NEW_TYPES) : pickRandom(OLD_TYPES);
    } else {
      // Hard: mix of old and new
      type = pickRandom(ALL_TYPES);
    }

    const width = getObstacleWidth(type);
    obstacles.push({
      type,
      x: 200 + Math.random() * (ARENA_WIDTH - 400),
      width,
      active: true,
      timer: 0,
      y: canvasH * 0.5 - 30 + (type === 'barrier' ? 0 : Math.random() * 20),
      direction: 1,
    });
  }
  return obstacles;
}

function getObstacleWidth(type: ObstacleType): number {
  switch (type) {
    case 'barrier': return 30;
    case 'oil-slick': return 60;
    case 'speed-burst': return 50;
    case 'boost-field': return 70;
    case 'slow-field': return 70;
    case 'banana-peel': return 35;
    case 'rubber-ducky': return 35;
    case 'speed-camera': return 25;
    case 'wormhole': return 45;
    default: return 40;
  }
}

export function updateObstacles(obstacles: Obstacle[], dt: number, canvasH: number): Obstacle[] {
  return obstacles.map((o) => {
    if (o.type === 'barrier') {
      const newY = o.y + o.direction * 40 * dt;
      let dir = o.direction;
      if (newY > canvasH * 0.5 + 40) dir = -1;
      if (newY < canvasH * 0.5 - 80) dir = 1;
      return { ...o, y: newY, direction: dir, timer: o.timer + dt };
    }
    return { ...o, timer: o.timer + dt };
  });
}

export function checkObstacleCollision(
  carX: number,
  obstacles: Obstacle[],
  existingEffects: ObstacleEffect[]
): { effects: ObstacleEffect[]; obstacles: Obstacle[] } {
  const newEffects = [...existingEffects];
  const updatedObstacles = obstacles.map((o) => {
    if (!o.active) return o;
    if (carX >= o.x - o.width / 2 && carX <= o.x + o.width / 2) {
      switch (o.type) {
        case 'barrier':
          newEffects.push({ type: 'barrier', timeLeft: 1.0 });
          break;
        case 'oil-slick':
          newEffects.push({ type: 'oil-slick', timeLeft: 1.5 });
          break;
        case 'speed-burst':
          newEffects.push({ type: 'speed-burst', timeLeft: 0.8 });
          break;
        case 'boost-field':
          newEffects.push({ type: 'boost-field', timeLeft: 1.2 });
          break;
        case 'slow-field':
          newEffects.push({ type: 'slow-field', timeLeft: 1.5 });
          break;
        case 'banana-peel':
          newEffects.push({ type: 'banana-peel', timeLeft: 0.8 });
          break;
        case 'rubber-ducky':
          newEffects.push({ type: 'rubber-ducky', timeLeft: 0.6 });
          break;
        case 'speed-camera':
          newEffects.push({ type: 'speed-camera', timeLeft: 1.0 });
          break;
        case 'wormhole':
          newEffects.push({
            type: 'wormhole',
            timeLeft: 0.3,
            teleportAmount: 60 + Math.random() * 40,
          });
          break;
      }
      return { ...o, active: false };
    }
    return o;
  });
  return { effects: newEffects, obstacles: updatedObstacles };
}

export function updateEffects(effects: ObstacleEffect[], dt: number): ObstacleEffect[] {
  return effects
    .map((e) => ({ ...e, timeLeft: e.timeLeft - dt }))
    .filter((e) => e.timeLeft > 0);
}

export function getBrakeMultiplier(effects: ObstacleEffect[]): number {
  let mult = 1.0;
  for (const e of effects ?? []) {
    if (e.type === 'barrier') mult *= 0.7;
    if (e.type === 'oil-slick') mult *= 0.6;
    if (e.type === 'slow-field') mult *= 0.5;
    if (e.type === 'banana-peel') mult *= 0.65;
    if (e.type === 'rubber-ducky') mult *= 0.55;
    if (e.type === 'speed-camera') mult *= 0.8;
  }
  return mult;
}

export function getAccelMultiplier(effects: ObstacleEffect[]): number {
  let mult = 1.0;
  for (const e of effects ?? []) {
    if (e.type === 'speed-burst') mult *= 1.5;
    if (e.type === 'boost-field') mult *= 2.0;
  }
  return mult;
}

export function drawObstacle(ctx: CanvasRenderingContext2D, o: Obstacle, scaleX: number, roadY: number, roadH: number): void {
  if (!o.active) return;
  const sx = o.x * scaleX;
  const sw = o.width * scaleX;
  const cy = roadY + roadH / 2;

  ctx.save();
  switch (o.type) {
    case 'barrier': {
      ctx.fillStyle = '#ff4400';
      ctx.shadowBlur = 8;
      ctx.shadowColor = '#ff4400';
      ctx.fillRect(sx - sw / 2, roadY - 5, sw, roadH + 10);
      ctx.strokeStyle = '#ffaa00';
      ctx.lineWidth = 2;
      ctx.strokeRect(sx - sw / 2, roadY - 5, sw, roadH + 10);
      ctx.fillStyle = '#ffaa00';
      for (let i = 0; i < 3; i++) {
        ctx.fillRect(sx - sw / 2 + i * (sw / 3), roadY - 5, sw / 6, roadH + 10);
      }
      ctx.shadowBlur = 0;
      break;
    }
    case 'oil-slick': {
      const gradient = ctx.createRadialGradient(sx, cy, 0, sx, cy, sw);
      gradient.addColorStop(0, 'rgba(100,50,200,0.6)');
      gradient.addColorStop(0.5, 'rgba(50,150,200,0.4)');
      gradient.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.ellipse(sx, cy, sw, roadH * 0.6, 0, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case 'speed-burst': {
      ctx.fillStyle = '#ffdd00';
      ctx.shadowBlur = 12;
      ctx.shadowColor = '#ffdd00';
      ctx.beginPath();
      ctx.moveTo(sx - sw * 0.3, cy - 15);
      ctx.lineTo(sx + sw * 0.1, cy - 3);
      ctx.lineTo(sx - sw * 0.1, cy + 3);
      ctx.lineTo(sx + sw * 0.3, cy + 15);
      ctx.lineTo(sx, cy + 3);
      ctx.lineTo(sx + sw * 0.15, cy - 3);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;
      break;
    }
    case 'boost-field': {
      // Bright green translucent stripe
      ctx.fillStyle = 'rgba(57, 255, 20, 0.25)';
      ctx.fillRect(sx - sw / 2, roadY, sw, roadH);
      ctx.strokeStyle = '#39ff14';
      ctx.lineWidth = 2;
      ctx.strokeRect(sx - sw / 2, roadY, sw, roadH);
      // Glow
      ctx.shadowBlur = 15;
      ctx.shadowColor = '#39ff14';
      ctx.strokeRect(sx - sw / 2, roadY, sw, roadH);
      ctx.shadowBlur = 0;
      // BOOST text
      ctx.fillStyle = '#39ff14';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('BOOST', sx, cy + 4);
      ctx.textAlign = 'left';
      // Sparkles
      const sparkT = o.timer * 5;
      for (let i = 0; i < 4; i++) {
        const sparkX = sx - sw / 3 + (i * sw / 3) + Math.sin(sparkT + i * 2) * 5;
        const sparkY = roadY + 6 + Math.cos(sparkT + i) * 4;
        ctx.fillStyle = '#aaffaa';
        ctx.beginPath();
        ctx.arc(sparkX, sparkY, 2, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    }
    case 'slow-field': {
      // Icy-blue translucent stripe
      ctx.fillStyle = 'rgba(100, 200, 255, 0.2)';
      ctx.fillRect(sx - sw / 2, roadY, sw, roadH);
      ctx.strokeStyle = '#66ccff';
      ctx.lineWidth = 2;
      ctx.strokeRect(sx - sw / 2, roadY, sw, roadH);
      ctx.shadowBlur = 12;
      ctx.shadowColor = '#66ccff';
      ctx.strokeRect(sx - sw / 2, roadY, sw, roadH);
      ctx.shadowBlur = 0;
      // SLOW text
      ctx.fillStyle = '#88ddff';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('SLOW', sx, cy + 4);
      ctx.textAlign = 'left';
      // Snowflakes
      ctx.fillStyle = '#ffffff';
      const snowT = o.timer * 3;
      for (let i = 0; i < 5; i++) {
        const sfx = sx - sw / 3 + (i * sw / 4) + Math.sin(snowT + i) * 3;
        const sfy = roadY + 5 + (i % 2) * (roadH - 10) + Math.cos(snowT + i * 1.5) * 3;
        ctx.font = '8px sans-serif';
        ctx.fillText('*', sfx, sfy);
      }
      break;
    }
    case 'banana-peel': {
      // Yellow splat
      ctx.fillStyle = 'rgba(255, 220, 0, 0.5)';
      ctx.beginPath();
      ctx.ellipse(sx, cy, sw * 0.6, roadH * 0.4, 0, 0, Math.PI * 2);
      ctx.fill();
      // Banana label
      ctx.font = '16px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('\u{1F34C}', sx, cy + 5);
      ctx.textAlign = 'left';
      break;
    }
    case 'rubber-ducky': {
      // Cute duck shape
      ctx.fillStyle = '#ffcc00';
      ctx.shadowBlur = 8;
      ctx.shadowColor = '#ffaa00';
      // Body (oval)
      ctx.beginPath();
      ctx.ellipse(sx, cy + 2, sw * 0.45, roadH * 0.35, 0, 0, Math.PI * 2);
      ctx.fill();
      // Head (smaller circle)
      ctx.beginPath();
      ctx.arc(sx + sw * 0.3, cy - roadH * 0.15, roadH * 0.18, 0, Math.PI * 2);
      ctx.fill();
      // Beak
      ctx.fillStyle = '#ff6600';
      ctx.beginPath();
      ctx.moveTo(sx + sw * 0.45, cy - roadH * 0.15);
      ctx.lineTo(sx + sw * 0.6, cy - roadH * 0.12);
      ctx.lineTo(sx + sw * 0.45, cy - roadH * 0.08);
      ctx.closePath();
      ctx.fill();
      // Eye
      ctx.fillStyle = '#000';
      ctx.beginPath();
      ctx.arc(sx + sw * 0.33, cy - roadH * 0.2, 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      // QUACK label
      ctx.fillStyle = '#ffee00';
      ctx.font = 'bold 9px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('QUACK!', sx, roadY - 3);
      ctx.textAlign = 'left';
      break;
    }
    case 'speed-camera': {
      // Grey pole on side of road
      const poleX = sx;
      const poleTop = roadY - 25;
      ctx.fillStyle = '#888';
      ctx.fillRect(poleX - 2, poleTop, 4, roadY - poleTop + 5);
      // Camera box
      ctx.fillStyle = '#666';
      ctx.fillRect(poleX - 8, poleTop - 2, 16, 12);
      ctx.strokeStyle = '#999';
      ctx.lineWidth = 1;
      ctx.strokeRect(poleX - 8, poleTop - 2, 16, 12);
      // Lens
      ctx.fillStyle = '#222';
      ctx.beginPath();
      ctx.arc(poleX, poleTop + 4, 3, 0, Math.PI * 2);
      ctx.fill();
      // Flash effect (pulsing)
      const flashPulse = Math.sin(o.timer * 8) * 0.5 + 0.5;
      if (flashPulse > 0.7) {
        ctx.fillStyle = `rgba(255, 255, 0, ${flashPulse * 0.6})`;
        ctx.shadowBlur = 15;
        ctx.shadowColor = '#ffff00';
        ctx.beginPath();
        ctx.arc(poleX, poleTop + 4, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
      // BUSTED label
      ctx.fillStyle = '#ffaa00';
      ctx.font = 'bold 8px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('CAMERA', poleX, poleTop - 6);
      ctx.textAlign = 'left';
      break;
    }
    case 'wormhole': {
      // Swirling purple portal
      const rings = 4;
      for (let i = rings; i >= 0; i--) {
        const radius = (sw * 0.5) * (i / rings) + 3;
        const hue = 270 + i * 15;
        const alpha = 0.3 + (1 - i / rings) * 0.4;
        ctx.strokeStyle = `hsla(${hue}, 80%, 60%, ${alpha})`;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(sx, cy, radius, o.timer * (2 + i * 0.5), o.timer * (2 + i * 0.5) + Math.PI * 1.5);
        ctx.stroke();
      }
      // Center glow
      const cg = ctx.createRadialGradient(sx, cy, 0, sx, cy, sw * 0.3);
      cg.addColorStop(0, 'rgba(167,139,250,0.6)');
      cg.addColorStop(1, 'rgba(100,50,200,0)');
      ctx.fillStyle = cg;
      ctx.beginPath();
      ctx.arc(sx, cy, sw * 0.3, 0, Math.PI * 2);
      ctx.fill();
      // WARP label
      ctx.fillStyle = '#c084fc';
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('WARP!', sx, roadY - 5);
      ctx.textAlign = 'left';
      break;
    }
  }
  ctx.restore();
}
