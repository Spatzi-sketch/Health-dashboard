export type MapId = 'tokyo-night' | 'sakura-pass' | 'neon-circuit' | 'ocean-drive' | 'space-drift' | 'crimson-dojo';

export type Difficulty = 'easy' | 'medium' | 'hard' | 'impossible';
export type ArenaSpeed = 'slow' | 'normal' | 'fast' | 'turbo';
export type BotStyle = 'aggressive' | 'tactical' | 'unpredictable';

export interface MapConfig {
  id: MapId;
  name: string;
  emoji: string;
  bgColor: string;
  accentColor: string;
  secondaryColor: string;
  roadColor: string;
  description: string;
}

export interface GameSettings {
  difficulty: Difficulty;
  arenaSpeed: ArenaSpeed;
  map: MapId;
  botStyle: BotStyle;
  playerColor: string;
}

export type ObstacleType =
  | 'barrier'
  | 'oil-slick'
  | 'speed-burst'
  | 'boost-field'
  | 'slow-field'
  | 'banana-peel'
  | 'rubber-ducky'
  | 'speed-camera'
  | 'wormhole';

export interface Obstacle {
  type: ObstacleType;
  x: number;
  width: number;
  active: boolean;
  timer: number;
  y: number;
  direction: number;
}

export interface ObstacleEffect {
  type: ObstacleType;
  timeLeft: number;
  /** For wormhole: teleport amount in arena units */
  teleportAmount?: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  opacity: number;
  color: string;
  rotation: number;
  rotationSpeed: number;
  life: number;
  maxLife: number;
}

export interface GameState {
  phase: 'countdown' | 'racing' | 'result';
  countdownValue: number;
  playerPos: number;
  playerVel: number;
  playerBraking: boolean;
  botPos: number;
  botVel: number;
  botBraking: boolean;
  winner: 'player' | 'bot' | 'draw' | null;
  resultType: 'safe' | 'crash' | null;
  playerBrakeTime: number;
  botBrakeTime: number;
  raceStartTime: number;
  elapsed: number;
  playerEffects: ObstacleEffect[];
  botEffects: ObstacleEffect[];
  obstacles: Obstacle[];
  impactText: string | null;
  impactTextTimer: number;
  shakeIntensity: number;
  /** Flag for banana jitter visual effect */
  playerJitter?: boolean;
  botJitter?: boolean;
  /** Flag for rubber ducky bounce visual effect */
  playerBounce?: boolean;
  botBounce?: boolean;
}

export interface GameStats {
  wins: number;
  losses: number;
  draws: number;
  bestBrakeTime: number | null;
  closestDistance: number | null;
  gamesPlayed: number;
}

export const PLAYER_COLORS = [
  '#00e5ff', '#ff3366', '#39ff14', '#ff8c00',
  '#a78bfa', '#ffdd00', '#ff00ff', '#ffffff'
];

// Free colors (always unlocked)
export const FREE_COLORS = ['#00e5ff', '#ffffff', '#a78bfa'];

// Locked colors with costs
export const LOCKED_COLOR_COSTS: Record<string, number> = {
  '#ff3366': 800,
  '#39ff14': 850,
  '#ff8c00': 750,
  '#ffdd00': 800,
  '#ff00ff': 1000,
};

// Free maps (always unlocked)
export const FREE_MAPS: MapId[] = ['tokyo-night', 'sakura-pass', 'neon-circuit'];

// Locked maps with costs
export const LOCKED_MAP_COSTS: Record<string, number> = {
  'ocean-drive': 750,
  'space-drift': 750,
  'crimson-dojo': 750,
};

// Coin earning formula constants
export const DIFFICULTY_COIN_MULTIPLIER: Record<Difficulty, number> = {
  easy: 0.20,
  medium: 0.40,
  hard: 0.70,
  impossible: 1.00,
};
